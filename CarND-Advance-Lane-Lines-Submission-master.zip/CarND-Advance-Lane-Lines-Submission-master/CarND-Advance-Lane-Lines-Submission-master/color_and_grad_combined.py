import cv2
import matplotlib.image as mpimg
import numpy as np
import glob
import matplotlib.pyplot as plt

import grad_thresholding as gt
import color_thresholding as ct

images = glob.glob('test_images/*.jpg')
gaussian_kernel=3


def show_gc_combined():
    for fname in images:
        image = cv2.imread(fname)
        #print(image.shape)
        grad_combined=gt.get_grad_combined(image)
        color_combined=ct.get_SThresholded(image)

        L_thresh = (100, 255)
        hls = cv2.cvtColor(image, cv2.COLOR_BGR2HLS)
        L = hls[:, :, 1]
        L_binary = np.zeros_like(L)
        L_binary[((L > L_thresh[0]) & (L <= L_thresh[1]))] = 1

        grad_color_combined = np.zeros_like(grad_combined)

        grad_color_combined[((grad_combined == 1) | (color_combined == 1))&(L_binary==1)] = 1

        #apply gaussian blurring
        #gaussian_combined=cv2.GaussianBlur(grad_color_combined, (gaussian_kernel, gaussian_kernel), 0)

        #ombined[((gradx == 1)) | ((dir_binary == 1) & (mag_binary == 1))] = 1

        #print(grad_combined.shape)

        image=cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
        # plot
        f, (ax1, ax2, ax3, ax4 ) = plt.subplots(1, 4, figsize=(24, 9))
        #f, ( (ax1, ax2), (ax3,ax4)) = plt.subplots(2, 2, figsize=(24, 9))
        f.tight_layout()

        ax1.imshow(image)
        ax1.set_title('original Image', fontsize=25)

        ax2.imshow(grad_combined, cmap='gray')
        ax2.set_title('grad_combined', fontsize=25)

        ax3.imshow(color_combined, cmap='gray')
        ax3.set_title('color_combined', fontsize=25)

        ax4.imshow(grad_color_combined, cmap='gray')
        ax4.set_title('gc_combined', fontsize=25)

        #ax5.imshow(gaussian_combined, cmap='gray')
        #ax5.set_title('gaussian_combined', fontsize=20)

        plt.subplots_adjust(left=0., right=1, top=0.9, bottom=0.)

        plt.savefig('output_images/gradient and color combined/' + fname.split('\\')[1])
        plt.show()

def get_gc_combined(image):

    L_thresh = (100, 255)

    hls = cv2.cvtColor(image, cv2.COLOR_RGB2HLS)
    L = hls[:, :, 1]

    L_binary = np.zeros_like(L)
    L_binary[((L > L_thresh[0]) & (L <= L_thresh[1]))] = 1

    grad_combined = gt.get_grad_combined(image)
    color_combined = ct.compare_HLS_RGB(image)

    grad_color_combined = np.zeros_like(grad_combined)

    grad_color_combined[((grad_combined == 1) | (color_combined == 1))&(L_binary==1)] = 1
    #grad_color_combined[(grad_color_combined==1) & (L_binary==1)] = 1

    # apply gaussian blurring
    #gaussian_combined = cv2.GaussianBlur(grad_color_combined, (gaussian_kernel, gaussian_kernel), 0)

    return grad_color_combined

def test():
    for fname in images:
        image = cv2.imread(fname)
        combined=get_gc_combined(image)
        plt.imshow(combined,cmap='gray')
        plt.show()

#test()
#show_gc_combined()