import cv2
import numpy as np
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import glob
from moviepy.editor import VideoFileClip
from IPython.display import HTML

import calibrate_and_undistort as cam_calibration
import color_and_grad_combined as gc_combined
import topview
import sliding_window

#1. calibrate camera
cam_calibration.calibrate_camera()
M,Minv=topview.get_perspective_matrix()

#camera_mtx,camera_dst=cam_calibration.get_cammtx_dstcoeff()
#print(M,Minv)
#print(camera_dst,camera_mtx)

def region_of_interest(img, vertices):


    mask = np.zeros_like(img)

    # defining a 3 channel or 1 channel color to fill the mask with depending on the input image
    if len(img.shape) > 2:
        channel_count = img.shape[2]  # i.e. 3 or 4 depending on your image
        ignore_mask_color = (255,) * channel_count
    else:
        ignore_mask_color = 255

    # filling pixels inside the polygon defined by "vertices" with the fill color
    cv2.fillPoly(mask, vertices, ignore_mask_color)

    # returning the image only where mask pixels are nonzero
    masked_image = cv2.bitwise_and(img, mask)
    return masked_image


def process_image_test(img,fname):

    f, (ax1, ax2, ax3,ax4,ax5) = plt.subplots(1, 5, figsize=(24, 9))
    f.tight_layout()

    #2.undistort image
    undistorted_img=cam_calibration.undistort(img)
    ax1.imshow(undistorted_img)
    ax1.set_title("undistored image")

    #. apply perspective transform
    thresholded_warped = topview.get_top_view(undistorted_img)
    ax2.imshow(thresholded_warped)
    ax2.set_title("thresholded warped")

    #3.apply gradient and color thresolding
    thresholded_warped_image=gc_combined.get_gc_combined(thresholded_warped)
    ax3.imshow(thresholded_warped_image,cmap='gray')
    ax3.set_title("thresholded image")

    # histogram = np.sum(np.unit8(thresholded_warped_image*255)[thresholded_warped_image.shape[0] // 2:, :], axis=0)
    #plt.plot(histogram)

    unwraped_weighted_img,histogram,output_img = sliding_window.plot_histogram(np.uint8(thresholded_warped_image * 255), undistorted_img,
                                                          Minv)
    #ax4.imshow(histogram)
    #ax4.set_title("histogram")

    ax4.imshow(output_img)
    ax4.set_title("sliding_windows")

    ax5.imshow(unwraped_weighted_img)
    ax5.set_title("unwarped_img")

    plt.savefig('output_images/histogram and unwarped final output/' + fname.split('\\')[1])
    plt.show()

    #return thresholded_warped


def process_image(img):
    # 2.undistort image
    undistorted_img = cam_calibration.undistort(img)

    vertices = np.array([[(180, 720), (1150, 720), (720, 430), (577, 430)]], dtype=np.int32)
    # vertices = np.array([[ (150, 720), (1020, 720),(1020, 0), (0, 0)]], dtype=np.int32)
    roi = region_of_interest(undistorted_img, vertices)

    warped = topview.get_top_view(roi)

    thresholded_warped_image = gc_combined.get_gc_combined(warped)
    # sliding_window.plot_histogram(thresholded_warped_image)
    # unwraped_weighted_img,left_curvature,right_curvature=sliding_window.plot_histogram(np.uint8(thresholded_warped_image * 255),undistorted_img,Minv)
    unwraped_weighted_img, left_curvature, right_curvature = sliding_window.plot_histogram(thresholded_warped_image,
                                                                                           undistorted_img, Minv)
    return unwraped_weighted_img
    # cl=np.dstack((thresholded_warped_image, thresholded_warped_image, thresholded_warped_image))*255
    # return cl


def test_mask():
    images = glob.glob('test_images/*.jpg')
    for fname in images:
        img = mpimg.imread(fname)
        c=process_image(img)
        #plt.imshow(c,cmap='gray')
        vertices = np.array([[ (0, 720), (1020, 720),(1020, 0), (0, 0)]], dtype=np.int32)
        roi = region_of_interest(c, vertices)
        plt.imshow(roi)
        plt.show()

def process_video():
    final_output = 'test_output_video/project_video_output.mp4'

    clip1 = VideoFileClip("project_video.mp4")#.subclip(0,2)

    undist_clip = clip1.fl_image(process_image) # NOTE: this function expects color images!!

    undist_clip.write_videofile(final_output, audio=False)

def pipeline_test_images():

    images = glob.glob('test_images/*.jpg')
    for fname in images:
        img = mpimg.imread(fname)
        process_image_test(img,fname)


#test_mask()
#pipeline_test_images()
#process_video()


