﻿## Writeup 

**Vehicle Detection Project**

The goals / steps of this project are the following:

* Perform a Histogram of Oriented Gradients (HOG) feature extraction on a labeled training set of images and train a classifier Linear SVM classifier
* Optionally, you can also apply a color transform and append binned color features, as well as histograms of color, to your HOG feature vector. 
* Note: for those first two steps don't forget to normalize your features and randomize a selection for training and testing.
* Implement a sliding-window technique and use your trained classifier to search for vehicles in images.
* Run your pipeline on a video stream (start with the test_video.mp4 and later implement on full project_video.mp4) and create a heat map of recurring detections frame by frame to reject outliers and follow detected vehicles.
* Estimate a bounding box for vehicles detected.

[//]: # (Image References)
[image1]: ./examples/car_not_car.png
[image2]: ./examples/HOG_example.jpg
[image3]: ./examples/sliding_windows.jpg
[image4]: ./examples/sliding_window.jpg
[image5]: ./examples/bboxes_and_heat.png
[image6]: ./examples/labels_map.png
[image7]: ./examples/output_bboxes.png
[video1]: ./project_video.mp4

## [Rubric](https://review.udacity.com/#!/rubrics/513/view) Points
### Here I will consider the rubric points individually and describe how I addressed each point in my implementation.  

---
### Writeup / README

You're reading it!

### Histogram of Oriented Gradients (HOG)

#### 1. Explain how (and identify where in your code) you extracted HOG features from the training images.

The code for this step is contained in the 4th code cell of the IPython notebook 

I started by reading in all the `vehicle` and `non-vehicle` images.  Here is an example of one of each of the `vehicle` and `non-vehicle` classes:

![PNG](writeup_images/car.PNG)


![PNG](writeup_images/notcar.PNG)


I then explored different color spaces and different `skimage.hog()` parameters (`orientations`, `pixels_per_cell`, and `cells_per_block`).  I grabbed random images from each of the two classes and displayed them to get a feel for what the `skimage.hog()` output looks like.


Here is an example using the `YUV` color space and HOG parameters of `orientations=11`, `pixels_per_cell=(8, 8)` and `cells_per_block=(2, 2)`:

![png](writeup_images/output_4_2.png)

#### 2. Explain how you settled on your final choice of HOG parameters.

I tried various combinations of parameters,<br>
`colorspace` :`YUV` I tried using 'YrCrCb', 'HLS' and 'YUV' color spaces,while 'YrCrCb' and 'YUV' gave similar results, 'HLS' detected a lot of false positives.
Finally, settled with 'YUV'
`orientations`:`12`  (also tried using 9,11,12), increasing from 9 to 12 resulted in better accuracy and removed false positives<br>
`pixels_per_cell`:`8` (also tried with 16)<br>
`cells_per_block`:`2`<br>
`hog_channel`:`'ALL'`<br>
`transform_sqrt`:`False`<br>

#### Color Features:
I also used both spatial and histogram of color features ,with<br>
`spatial_size`:`(16,16)`<br>
`hist_bins`:`8`

#### Total length of feature vector :`7260`
#### Time taken:	`94.37s`
	
#### 3. Describe how (and identify where in your code) you trained a classifier using your selected HOG features (and color features if you used them).

The code for this step is contained in the 15th code cell of the jupyter notebook 

I split the data into training and test data with test size 0.2 times the training data. Used Sklearn's StandardScaler to scale the features. Then used a linear SVM to train. 

`Accuracy of the classifier` :	`99.04`(running it multiple times returns accuracy in range 98.5-99.2)<br>
` Time taken to train`:	`94.37s`


#### Sliding Window Search

#### 1. Describe how (and identify where in your code) you implemented a sliding window search.  How did you decide what scales to search and how much to overlap windows?
The code for this step is contained in the 17th code cell of the jupyter notebook 

I used `Hog Subsampling` to get the hog features.
I used `multiple scales`, with different region of interests for each scale.<br>
The final configuration i settled with:<br>
ystarts=[380,400,472,496],<br>
ystops =[476,560,560,656], <br>
scales=[1.0,1.5,2.0,2.5]<br>
cells_per_step=2, which here comes to 75% overlap<br>
Using different ROI for different scales, speeded up my pipeline by a factor of around 3.


#### 2. Show some examples of test images to demonstrate how your pipeline is working.  What did you do to optimize the performance of your classifier?

Ultimately I searched on 4 scales using YUV 3-channel HOG features plus spatially binned color and histograms of color in the feature vector, which provided a nice result.  Here are some example images:

![png](writeup_images/output_12_2.png)
![png](writeup_images/output_12_6.png)
![png](writeup_images/output_12_8.png)


### Video Implementation

#### 1. Provide a link to your final video output.  Your pipeline should perform reasonably well on the entire project video (somewhat wobbly or unstable bounding boxes are ok as long as you are identifying the vehicles most of the time with minimal false positives.)
Here's a [link to my video result ,YUV model,with smoothening over frames](https://github.com/anupamhap/CarND-Vehicle-Detection/raw/master/test_output_video/yuv_11_8_smoothened.mp4)

Here's a [link to my video result, YUV model without smoothening](https://github.com/anupamhap/CarND-Vehicle-Detection/raw/master/test_output_video/yuv_11_8.mp4)

Here's a [link to my video result,YCrCb model without smothening](https://github.com/anupamhap/CarND-Vehicle-Detection/raw/master/test_output_video/YrCrCb%2011%2016%208.mp4)


#### 2. Describe how (and identify where in your code) you implemented some kind of filter for false positives and some method for combining overlapping bounding boxes.
The code for this step is contained in the 21st code cell of the IPython notebook (`apply_threshold` and `draw_labeled_bboxes` function)

I recorded the positions of positive detections in each frame of the video.  From the positive detections I created a heatmap and then thresholded that map to identify vehicle positions.  I then used `scipy.ndimage.measurements.label()` to identify individual blobs in the heatmap.  I then assumed each blob corresponded to a vehicle.  I constructed bounding boxes to cover the area of each blob detected.  

I also kept a `history` of heatmaps of last 5 frames (using a deque),and summed up the heats. This made the positive detections  more hotter,thereby smoothening them and making it easily separable from false positives.(24th cell of jupyter notebook)

Here's an example result showing the heatmap from a series of frames of video, the result of `scipy.ndimage.measurements.label()` and the bounding boxes then overlaid on the last frame of video:

### Here are six frames and their corresponding heatmaps,thresholded heatmaps and final output:

![png](writeup_images/output_16_1.png)
![png](writeup_images/output_16_2.png)
![png](writeup_images/output_16_3.png)
![png](writeup_images/output_16_4.png)
![png](writeup_images/output_16_5.png)
![png](writeup_images/output_16_6.png)

The complete list can be found in output_images folder

### Discussion

#### 1. Briefly discuss any problems / issues you faced in your implementation of this project.  Where will your pipeline likely fail?  What could you do to make it more robust?

- There became a need of a lot of parameter tuning , especially in selecting ROIs in sliding window for the different scales. Initially, the video was being processed at about 2.4 `s/it`, but afterwards, it ran at about 1.4 `it/s`. 
Before proper tuning of the classifier, a lot of false positives were detected.

- The pipeline will not work in real time. The current state of art Deep neural network models like `YOLO or SSD ` could be used, for faster and more accurate results.
- As no of features are large, decision tree can be used to identify only those features that matter.


