# CarND-lanes
detecting lane lines using traditional computer vision techniques
