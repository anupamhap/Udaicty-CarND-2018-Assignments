﻿

# **Traffic Sign Recognition** 

## Writeup
---

**Build a Traffic Sign Recognition Project**

The goals / steps of this project are the following:
* Load the data set (see below for links to the project data set)
* Explore, summarize and visualize the data set
* Design, train and test a model architecture
* Use the model to make predictions on new images
* Analyze the softmax probabilities of the new images
* Summarize the results with a written report


[//]: # (Image References)

[image1]: ./examples/visualization.jpg "Visualization"
[image2]: ./examples/grayscale.jpg "Grayscaling"
[image3]: ./examples/random_noise.jpg "Random Noise"
[image4]: ./examples/placeholder.png "Traffic Sign 1"
[image5]: ./examples/placeholder.png "Traffic Sign 2"
[image6]: ./examples/placeholder.png "Traffic Sign 3"
[image7]: ./examples/placeholder.png "Traffic Sign 4"
[image8]: ./examples/placeholder.png "Traffic Sign 5"

## Rubric Points
### Here I will consider the [rubric points](https://review.udacity.com/#!/rubrics/481/view) individually and describe how I addressed each point in my implementation.  

---
### Writeup / README

#### 1. Provide a Writeup / README that includes all the rubric points and how you addressed each one. You can submit your writeup as markdown or pdf. You can use this template as a guide for writing the report. The submission includes the project code.

You're reading it! and here is a link to my [project code](https://github.com/anupamhap/Traffic_sign_classifier_submission/blob/master/Traffic_Sign_Classifier.ipynb)

### Data Set Summary & Exploration

#### 1. Provide a basic summary of the data set. In the code, the analysis should be done using python, numpy and/or pandas methods rather than hardcoding results manually.

I used the numpy library  to calculate summary statistics of the traffic
signs data set:

* The size of training set is 34799
* The size of the validation set is 4410
* The size of test set is 12630
* The shape of a traffic sign image is (32, 32, 3)
* The number of unique classes/labels in the data set is 43

#### 2. Include an exploratory visualization of the dataset.

Here is an exploratory visualization of the data set. It is a bar chart showing how the data is distributed,showing the frequency of each unique traffic_sign

![alt text](writeUp_images/output_12_0.png)

Plot of all unique traffic signs present in training data

![alt text](writeUp_images/output_10_0.png)


### Design and Test a Model Architecture

#### 1. Describe how you preprocessed the image data. What techniques were chosen and why did you choose these techniques? Consider including images showing the output of each preprocessing technique. Pre-processing refers to techniques such as converting to grayscale, normalization, etc. (OPTIONAL: As described in the "Stand Out Suggestions" part of the rubric, if you generated additional data for training, describe why you decided to generate additional data, how you generated the data, and provide example images of the additional data. Then describe the characteristics of the augmented training set like number of images in the set, number of images for each class, etc.)

##   PRE-PROCESSING STEPS

My pre-processing steps are heavily influenced by https://navoshta.com/traffic-signs-classification, as i found it worked best for my model.

## 1. Gray-scaling

As a first step, I decided to convert the images to grayscale because , i found grayscaling to perform slightly in terms of accuracy for this particular dataset,
With RGB, i was reaching validation accuracies of 91-93, 
and with Grayscale,  i reached validation accuracies of 93-96, along with other adjustments of hyperparameters.

## 2. Normalisation

I normalized the image data because normalization usually helps in faster convergence of training.

I tried scaling the image to (-1,1) and (0,1), and found scaling to (0,1) worked better.

## 3.Local contrast enhancement

I used skimage.exposure.equalize_adapthist function to enhance the contrast of the images. As a lot of images in the training data are of low contrast, using this, improved the model significantly.

A sample image before normalisation,

![alt text](writeUp_images/output_20_0.png)

After grayscale transformation,   
![alt text](writeUp_images/output_20_3.png)

After local contrast enhancement,

![alt text](writeUp_images/output_20_1.png)

## Data Augmentation
I attempted data augmenation, following the article at https://github.com/vxy10/ImageAugmentation, 


Its better to generate additional data, as it prevents the model from getting biased towards classes that have more frequency in training data.

As influenced by the article ,to add more data to the the data set, I tried using a linear combination of rotation, translation 
and shearing, to generate a fake image.

I increased the frequency of each class to 2450 , to make sure augmenation is applied accross all type of traffic signs, and the dataset is balanced.

The difference between the original data set and the augmented data set which i had was 105350-37499=70551

But i was not able to improvee accuracy further, so i skipped augmntation. I assume a deeper or wider network architecture could have been helpful here. 


#### 2. Describe what your final model architecture looks like including model type, layers, layer sizes, connectivity, etc.) Consider including a diagram and/or table describing the final model.

My final model consisted of the following layers:

| Layer         		|     Description	        					| 
|:---------------------:|:---------------------------------------------:| 
| Input         		| 32x32x1 grayscale image   							| 
| Convolution 5x5     	| 1x1 stride, valid padding,  outputs 28x28x6 	|
| RELU					|	(after relu,	keep_prob=0.7 is applied	)									|
| Max pooling	      	| 2x2 stride,  outputs 14x14x6 				|
| Convolution 5x5	    | 1x1 stride, valid padding, keep_prob=0.8 outputs 10x10x16       									|
|  RELU		|      			(after relu,	keep_prob=0.8 is applied	)						|
| 	Max pooling	      	| 2x2 stride,  outputs 5x5x16 				| etc.        									|
|	Flatten			|	5x5x16 - 400									|
|	Fully Connected			|	400 inputs to 120 outputs, bias 120											
 | Relu						| after Relu, keep_prob of 0.7 is applied					|
 | Fully Connected		|	120 inputs to 84 outputs,bias 84
 | Relu					|	after Relu, keep_prob of 0.8 is applied
 |Output Layer          |   84 inputs to 43 outputs,bias 43

#### 3. Describe how you trained your model. The discussion can include the type of optimizer, the batch size, number of epochs and any hyperparameters such as learning rate.

To train the model, I used the popular Lenet Architecture,
with following configuration
optimizer :- Adam Optimizer
learning rate :-0.001
epoch:- 40
batch_size:-256

I used dropouts to reduce overfitting, at following layers:
convolution layer1 : 0.7
convolution layer2 : 0.8
fully connected layer 1:0.7 
fully connected layer 2: 0.8

Loss plot:

![alt text](writeUp_images/output_39_0.png)


#### 4. Describe the approach taken for finding a solution and getting the validation set accuracy to be at least 0.93. Include in the discussion the results on the training, validation and test sets and where in the code these were calculated. Your approach may have been an iterative process, in which case, outline the steps you took to get to the final solution and why you chose those steps. Perhaps your solution involved an already well known implementation or architecture. In this case, discuss why you think the architecture is suitable for the current problem.

My final model results were:
* training set accuracy of : 1.000
* validation set accuracy of : 0.943
* test set accuracy of : 0.93.3

If a well known architecture was chosen:
* What architecture was chosen?
* Why did you believe it would be relevant to the traffic sign application?
* How does the final model's accuracy on the training, validation and test set provide evidence that the model is working well?

I choosed the well known LeNet Architecture. It performs well on digit recognition problem, so it might as well perform better with 43 classes. However, it appears, for Trafffic Sign Recognition problem, pre-processing of data is a very important factor .
I think, had the images used in training,were not already center positioned, and pre-processed, LeNet would not have been an ideal model. 

With only grayscaling and normalisation , my validation accuracy went upto 92%, 
After using local contrast enhancement as well, it reached a validation accuracy upto 94-95.
To further increase it, i tried data augmenation, and increased the frequency of all classes to 2450  to balance all classes, with a total training data of 105350. But the standard Lenet was not able to perform better with this huge data, and probably a  more deeper or wider network was needed.
 
### Test a Model on New Images

#### 1. Choose five German traffic signs found on the web and provide them in the report. For each image, discuss what quality or qualities might be difficult to classify.

I used 6 images German traffic signs from web.
I rescaled all the 6 images online to convert them to 32*32 width and height
I also converted all images to jpeg format, so the number of channels is 3.
I also took care to select images , which have the traffic sign centered in them, because my model was trained with such pre-processed images.

With this, I found my model recognized 5 out of 6 images which i selected.

![alt text](writeUp_images/output_44_1.png) ![alt text](writeUp_images/output_44_3.png) ![alt text](writeUp_images/output_44_5.png) 
![alt text](writeUp_images/output_44_7.png) ![alt text](writeUp_images/output_44_9.png) ![alt text](writeUp_images/output_44_11.png)

#### 2. Discuss the model's predictions on these new traffic signs and compare the results to predicting on the test set. At a minimum, discuss what the predictions were, the accuracy on these new predictions, and compare the accuracy to the accuracy on the test set (OPTIONAL: Discuss the results in more detail as described in the "Stand Out Suggestions" part of the rubric).

Here are the results of the prediction:

| Image			        |     Prediction	        					| 
|:---------------------:|:---------------------------------------------:| 
| Go straight or right      		| Go straight or right  									| 
| Ahead only    			| Ahead only 										|
| Keep right					|Keep right										|
| No entry   		| No entry				 				|
| Road work	| Road work    							|						|
|Priority road 		|No vehicles 


The model was able to correctly guess 5 of the 6 traffic signs, which gives an accuracy of 83.3%. This compares favorably to the accuracy on the test set of  93.3%. 
#### 3. Describe how certain the model is when predicting on each of the five new images by looking at the softmax probabilities for each prediction. Provide the top 5 softmax probabilities for each image along with the sign type of each probability. (OPTIONAL: as described in the "Stand Out Suggestions" part of the rubric, visualizations can also be provided such as bar charts)

For the first image, the model is completely sure that this is a 'go straight or right' sign (probability of 0.99), and the image does contain a 'go straight or right' sign. The top five soft max probabilities were

| Probability         	|     Prediction	        					| 
|:---------------------:|:---------------------------------------------:| 
| 9.99975204e-01       			| Go straight or right  									| 
| 2.08424917e-05     				| Road work										|
| 3.86090369e-06					| Priority road											|
| 5.89965836e-08	      			| Ahead only					 				|
| 5.73386103e-08				    | General caution     							|


For the second image ,the model is completely sure that this is a 'ahead only' sign (probability of 0.99), and the image does contain a 'ahead only' sign. The top five soft max probabilities were

| Probability         	|     Prediction	        					| 
|:---------------------:|:---------------------------------------------:| 
| 9.99958515e-01      			| Ahead only  									| 
| 3.76254247e-05     				| Yield										|
| 3.86981583e-06					| Priority road										|
| 2.38777731e-09	      			| Go straight or right					 				|
|7.99019961e-10				    | Road work    							|
For the third image ,the model is completely sure that this is a 'keep right' sign (probability of 0.99), and the image does contain a 'keep right' sign. The top five soft max probabilities were

| Probability         	|     Prediction	        					| 
|:---------------------:|:---------------------------------------------:| 
|9.99970913e-01      			| Keep Right 									| 
| 2.16922508e-05     				| End of no passing										|
| 7.29756312e-06					|Dangerous curve to the right										|
| 6.75543959e-08	      			| No passing				 				|
|5.37656639e-08				    | Children crossing    							|
For the fourth image ,the model is completely sure that this is a 'No entry' sign (probability of 1.00), and the image does contain a 'No entry' sign. The top five soft max probabilities were

| Probability         	|     Prediction	        					| 
|:---------------------:|:---------------------------------------------:| 
|1.00000000e+00      			| No entry 									| 
| 6.37948627e-09     				| Stop										|
| 5.33464870e-11					|Yield										|
| 1.11242699e-12	      			| Bumpy Road				 				|
|6.42045228e-13				    | Speed Limit(20km/h)    							|
For the fifth image ,the model is only about 51% sure that this is a 'Road work' sign (probability of 0.51), and the image does contain a 'Road work' sign. The top five soft max probabilities were

| Probability         	|     Prediction	        					| 
|:---------------------:|:---------------------------------------------:| 
|5.14833868e-01      			| Road work 									| 
| 4.02585268e-01     				| Bumpy road									|
| 7.70603940e-02					|Bicycles crossing										|
| 5.50515996e-03	      			| Wild animals crossing				 				|
| 6.60882824e-06				    |Slippery road   							|
For the sixth image ,the model predicted wrong that this is a 'No vehicles' sign  while the image contains a 'Priority road' sign. It may be because priority road image which i downloaded from internet may have a lot of background noise.The top five soft max probabilities were

| Probability         	|     Prediction	        					| 
|:---------------------:|:---------------------------------------------:| 
9.99880672e-01      			| No vehicles 									| 
| 1.06838947e-04     				| Priority road										|
| 1.24956405e-05 					|Yield										|
| 9.22145471e-09	      			| No passing				 				|
|1.14371224e-09				    | End of all speed and passing limits   							|
### (Optional) Visualizing the Neural Network (See Step 4 of the Ipython notebook for more details)
#### 1. Discuss the visual output of your trained network's feature maps. What characteristics did the neural network use to make classifications?


## Remarks:
1. Please find the downloaded images in the 'final image testing ' directory.


