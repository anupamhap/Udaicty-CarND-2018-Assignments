﻿
# **Behavioral Cloning** 

## Writeup Template


**Behavioral Cloning Project**

The goals / steps of this project are the following:
* Use the simulator to collect data of good driving behavior
* Build, a convolution neural network in Keras that predicts steering angles from images
* Train and validate the model with a training and validation set
* Test that the model successfully drives around track one without leaving the road
* Summarize the results with a written report


[//]: # (Image References)

[image1]: ./examples/placeholder.png "Model Visualization"
[image2]: ./examples/placeholder.png "Grayscaling"
[image3]: ./examples/placeholder_small.png "Recovery Image"
[image4]: ./examples/placeholder_small.png "Recovery Image"
[image5]: ./examples/placeholder_small.png "Recovery Image"
[image6]: ./examples/placeholder_small.png "Normal Image"
[image7]: ./examples/placeholder_small.png "Flipped Image"

## Rubric Points
### Here I will consider the [rubric points](https://review.udacity.com/#!/rubrics/432/view) individually and describe how I addressed each point in my implementation.  

---
### Files Submitted & Code Quality

#### 1. Submission includes all required files and can be used to run the simulator in autonomous mode

My project includes the following files:
* model.py containing the script to create and train the model
* drive.py for driving the car in autonomous mode
* nvidia_5epochs.h5 and nvidia_2epochs.h5(renamed from model.h5) containing a trained convolution neural network 
* nvidia_5Epochs.mp4 and nvidia_2Epochs
* writeup_report.md  summarizing the results

#### 2. Submission includes functional code
Using the Udacity provided simulator and my drive.py file, the car can be driven autonomously around the track by executing 
```sh
python drive.py nvidia_5epochs.h5
or
python drive.py nvidia_2epochs.h5
```

#### 3. Submission code is usable and readable

The model.py file contains the code for training and saving the convolution neural network. The file shows the pipeline I used for training and validating the model, and it contains comments to explain how the code works.

### Model Architecture and Training Strategy

#### 1. An appropriate model architecture has been employed

My model is highly influenced by the popular Nvidia architecture, as described in https://arxiv.org/pdf/1604.07316v1.pdf (model.py, lines 111-130)

Only modification which i made is used 'elu' activation layers instead of 'relu' as 'elu' which speeds up learning in deep neural networks. I was able to build a working model in just 2 epochs.  Also submitted another model ([nvidia_5epochs)](https://github.com/anupamhap/CarND-Behavorial-Cloning/raw/master/nvidia_5epochs.h5) ,trained for 5 epochs.

![alt text](./writeUp_Images/nvidia_architecture.png)

image source: https://arxiv.org/pdf/1604.07316v1.pdf

#### 2. Attempts to reduce overfitting in the model

The model uses all suggested data augmentation steps from classroom, to reduce overfitting, which includes :

 - **Flipping**: to reduce the left lane bias, as the first track is biased towards taking left turns. (model.py 23-24/ 84-101)
 - **Recovery**: recovery from left lane to center or right lane to center, is done by augmenting images from both left and right cameras ,with correction factor of +/- 0.25 (model.py 62-82)
 
The model was trained and validated on different data sets to ensure that the model was not overfitting (code line 165-168). The model was tested by running it through the simulator and ensuring that the vehicle could stay on the track.

![alt text](./writeUp_Images/mse.png)
mse loss for first 5 epochs :

As it can be seen from the image above, the model didnot overfit. Had it overfitted, popular methods like dropping or regularization could be used.

#### 3. Model parameter tuning

The model used an adam optimizer, so the learning rate was not tuned manually (model.py line 154).

EPOCHS: tried with 2 and 5, model working for both
BATCH_SIZE:32
CORRECTION_FACTOR:+/-0.25 (for steering angle of left and right images)

#### 4. Appropriate training data

I used the data given by udacity plus augmentation for training, as i was not able to collect manual data from simulator, due to slow processor.

After augmentation(left/right angle images and flipping), my training data was increased by 6 times, ie (38,568 samples)

### Model Architecture and Training Strategy

#### 1. Solution Design Approach

The overall strategy for deriving a model architecture was to ...

My first step was to use a convolution neural network model similar to the nvidia architecture. I thought this model might be appropriate because ...

In order to gauge how well the model was working, I split my image and steering angle data into a training and validation set. Then i augmented flipped images of left,right and center images with the measurements adjusted accordingly. I found that i had low difference in mse of training and validation, so the model wasn't overfitting.

At the end of the process, the vehicle is able to drive autonomously around the track without leaving the road.

#### 2. Final Model Architecture

The final model architecture (model.py lines 111-130) consisted of a convolution neural network with the following layers and layer sizes ...

Here is a visualization of the architecture (note: visualizing the architecture is optional according to the project rubric)

![alt text](./writeUp_Images/model_arch.png)

#### 3. Creation of the Training Set & Training Process

I used the given udacity's data, as i was not able to record good driving data in my machine(slow processor)

Here is an example of center, left and right image,

![alt text](./writeUp_Images/center_2016_12_01_13_31_13_991.jpg)
![alt text](./writeUp_Images/left_2016_12_01_13_31_13_991.jpg)
![alt text](./writeUp_Images/right_2016_12_01_13_31_13_991.jpg)

I also added the flipped images of the above, to augment dataset and reduce bias towards left side,

![alt text](./writeUp_Images/center_2016_12_01_13_31_13_991_flipped.png)
![alt text](./writeUp_Images/left_2016_12_01_13_31_13_991_flipped.png)
![alt text](./writeUp_Images/right_2016_12_01_13_31_13_991_flipped.png)


After the collection process, I had 38,568 number of data points. I then preprocessed this data by cropping the images 70 pixels from the top and 25 pixels from the bottom.

I put 20% of the data into a validation set. I shuffled the data in the data_generator function(model.py line 43)

I used this training data for training the model. The validation set helped determine if the model was over or under fitting. The ideal number of epochs was 2 to 5. Further training could have reduced the loss, but i found  that the vehicle ran properly in the first track for both the models at epoch 2 and 5, so i stopped training. I used an adam optimizer so that manually training the learning rate wasn't necessary.

