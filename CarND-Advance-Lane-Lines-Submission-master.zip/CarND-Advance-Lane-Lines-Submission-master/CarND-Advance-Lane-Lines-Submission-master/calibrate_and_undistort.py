import matplotlib
import numpy as np
import cv2
import glob
import matplotlib.pyplot as plt
#%matplotlib qt
import matplotlib.image as mpimg
# prepare object points, like (0,0,0), (1,0,0), (2,0,0) ....,(6,5,0)
objp = np.zeros((6*9,3), np.float32)
objp[:,:2] = np.mgrid[0:9,0:6].T.reshape(-1,2)

# Arrays to store object points and image points from all the images.
objpoints = [] # 3d points in real world space
imgpoints = [] # 2d points in image plane.

camera_mtx=None
camera_dst=None

# Make a list of calibration images
images = glob.glob('camera_cal/calibration*.jpg')
img1= cv2.imread(images[0])

#print(len(images))

def get_obj_imgpoints(img, objpoints, imgpoints):
    # Find the chessboard corners
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, corners = cv2.findChessboardCorners(gray, (9, 6), None)

    # If found, add object points, image points
    if ret == True:
        objpoints.append(objp)
        imgpoints.append(corners)

def undistort(img):
    mtx,dist=get_cammtx_dstcoeff()
    undist = cv2.undistort(img, mtx, dist, None, mtx)
    return undist

def save_undistored_images():

    for fname in images:
        img = cv2.imread(fname)
        undistorted_image=undistort(img)

        # draw chessboard corners on each image
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        ret, corners = cv2.findChessboardCorners(gray, (9, 6), None)
        img = cv2.drawChessboardCorners(img, (9, 6), corners, ret)
        #print(fname.split('\\')[1])
        cv2.imwrite('output_images/undistorted test images/ '+fname.split('\\')[1],undistorted_image)

        # f, (ax1, ax2) = plt.subplots(1, 2, figsize=(24, 9))
        # f.tight_layout()
        # ax1.imshow(img)
        # ax1.set_title('Original Image', fontsize=50)
        # ax2.imshow(undistorted_image)
        # ax2.set_title('Undistorted Image', fontsize=50)
        # plt.subplots_adjust(left=0., right=1, top=0.9, bottom=0.)
        # plt.show()
    #cv2.imshow('img',img)
    #cv2.waitKey(500)

#print("anupam")
#cv2.destroyAllWindows()

def calibrate_camera():
    # Step through the list and search for chessboard corners
    for fname in images:
        img = cv2.imread(fname)
        get_obj_imgpoints(img, objpoints, imgpoints)

    ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(objpoints, imgpoints, img1.shape[:2], None, None)
    global camera_mtx
    global camera_dst
    camera_mtx=mtx
    camera_dst=dist

def get_cammtx_dstcoeff():
    return camera_mtx,camera_dst

#calibrate_camera()
#save_undistored_images()

#print(camera_mtx)
#img=mpimg.imread('test_images/test3.jpg')
#un=undistort(img)
#plt.imshow(un)
#plt.show()
#show_undistored_images()