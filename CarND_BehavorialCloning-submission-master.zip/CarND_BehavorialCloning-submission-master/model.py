import csv
import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from keras.models import Sequential
from keras.callbacks import ModelCheckpoint
from keras.layers import Flatten, Dense, Lambda, Cropping2D, Convolution2D, ELU, Dropout


def readCsv():
    lines = []
    
    with open('data/driving_log.csv') as csvfile:
        reader = csv.reader(csvfile)
        for line in reader:
            lines.append(line)
    return lines


def flip(center_image, center_angle):
    return np.fliplr(center_image), -center_angle


def get_image_atAngle(filepath, center_angle, param):
    correction = 0.25
    new_image = mpimg.imread(filepath)
    # new_image = cv2.cvtColor(new_image, cv2.COLOR_BGR2RGB)

    if param == 'right':
        new_angle = center_angle - correction
    else:
        new_angle = center_angle + correction

    return new_image, new_angle


def data_generator(samples, batch_size=32):
    num_samples = len(samples)
    while 1:  # Loop forever so the generator never terminates
        shuffle(samples)
        for offset in range(0, num_samples, batch_size):
            batch_samples = samples[offset:offset + batch_size]

            images = []
            angles = []
            for batch_sample in batch_samples:
                
                ######################ADD CENTER IMAGE FIRST #########################################
                
                center_img_path = './data/IMG/' + batch_sample[0].split('/')[-1]
                center_image = mpimg.imread(center_img_path)
                # center_image = cv2.cvtColor(center_image, cv2.COLOR_BGR2RGB)
                center_angle = float(batch_sample[3])
                images.append(center_image)
                angles.append(center_angle)
                
                #######################################################################################

                ###################### ADD OTHER CAMERA IMAGES ########################################
                
                left_img_path = './data/IMG/' + batch_sample[1].split('/')[-1]
                right_img_path = './data/IMG/' + batch_sample[2].split('/')[-1]
                
                left_image = mpimg.imread(left_img_path)                
                left_image_angle = float(batch_sample[3]) + 0.25

                right_image = mpimg.imread(right_img_path)              
                right_image_angle = float(batch_sample[3]) - 0.25
                
                #left_image,left_image_angle = get_image_atAngle(right_img_path,center_angle,'left')
                #right_image,right_image_angle = get_image_atAngle(right_img_path,center_angle,'right')
                
                images.append(left_image)
                angles.append(left_image_angle)

                images.append(right_image)
                angles.append(right_image_angle)
                
                ########################################################################################
              
                ###################### FLIP ALL 3 IMAGES(to remove left or right bias)##################
                
                # add center flipped images
                flipped_center_image, flipped_center_angle = flip(center_image, center_angle)
                images.append(flipped_center_image)
                angles.append(flipped_center_angle)

                # add left flipped images
                flipped_left_image, flipped_left_angle = flip(left_image, left_image_angle)
                images.append(flipped_left_image)
                angles.append(flipped_left_angle)

                # add right flipped images
                flipped_right_image, flipped_right_angle = flip(right_image, right_image_angle)
                images.append(flipped_right_image)
                angles.append(flipped_right_angle)
                
                ########################################################################################


            # convert to numpy array and save
            X_train = np.array(images)
            y_train = np.array(angles)

            shuffle(X_train, y_train)
            yield (X_train, y_train)

def get_nvidia_model():  #nvidia architecture used,only all activation functions changed to 'elu'
   
    model = Sequential()
    model.add(Cropping2D(cropping=((70, 25), (0, 0)), input_shape=(160, 320, 3)))
    model.add(Lambda(lambda x: x / 127.5 - 1.0))

    model.add(Convolution2D(24, 5, 5, subsample=(2, 2), activation='elu'))
    model.add(Convolution2D(36, 5, 5, subsample=(2, 2), activation='elu'))
    model.add(Convolution2D(48, 5, 5, subsample=(2, 2), activation='elu'))
    model.add(Convolution2D(64, 3, 3, activation='elu'))
    model.add(Convolution2D(64, 3, 3, activation='elu'))

    model.add(Flatten())
    model.add(Dense(100,activation='elu'))
    model.add(Dense(50,activation='elu'))
    model.add(Dense(10,activation='elu'))
    model.add(Dense(1))
    model.summary()
    model.compile(loss='mse', optimizer='adam')
    return model

def get_commaAI_model():
  
    #commaAI architecture used, influenced by 
    #https://github.com/commaai/research/blob/master/train_steering_model.py
  
    model = Sequential()
    model.add(Lambda(lambda x: (x / 127.5) - 1., input_shape=(160, 320, 3)))
    model.add(Cropping2D(cropping=((70, 25), (0, 0)), input_shape=(160, 320, 3)))
    model.add(Convolution2D(16, 8, 8, subsample=(4, 4), border_mode="same"))
    model.add(ELU())
    model.add(Convolution2D(32, 5, 5, subsample=(2, 2), border_mode="same"))
    model.add(ELU())
    model.add(Convolution2D(64, 5, 5, subsample=(2, 2), border_mode="same"))
    model.add(Flatten())
    model.add(Dropout(.2))
    model.add(ELU())
    model.add(Dense(512))
    model.add(Dropout(.5))
    model.add(ELU())
    model.add(Dense(1))

    model.summary()
    model.compile(optimizer="adam", loss="mse")
    return model


def main():
    
    BATCH_SIZE = 32
    EPOCHS = 2

    samples = readCsv()
    samples = samples[1:]
    training_samples, validation_samples = train_test_split(samples, test_size=0.2)

    train_generator = data_generator(training_samples, batch_size=32)
    validation_generator = data_generator(validation_samples, batch_size=32)
    
    model = get_nvidia_model()
    #model = get_commaAI_model()
    
    #filepath="anupam1.h5"
    #checkpoint = ModelCheckpoint(filepath, monitor='val_loss', verbose=1, save_best_only=True, mode='min')
    #callbacks_list = [checkpoint]
    
    model.fit_generator(train_generator,
                        samples_per_epoch=6 * len(training_samples),
                        validation_data=validation_generator,
                        nb_val_samples=len(validation_samples),
                        nb_epoch=EPOCHS,
                        #callbacks =callbacks_list,
                        verbose=1)

    model.save('nvidia_2epochs.h5')
    #model.save('commaAI_model.h5')


if __name__ == '__main__':
    main()
