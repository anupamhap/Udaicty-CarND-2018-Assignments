
# Self-Driving Car Engineer Nanodegree

## Deep Learning

## Project: Build a Traffic Sign Recognition Classifier

In this notebook, a template is provided for you to implement your functionality in stages, which is required to successfully complete this project. If additional code is required that cannot be included in the notebook, be sure that the Python code is successfully imported and included in your submission if necessary. 

> **Note**: Once you have completed all of the code implementations, you need to finalize your work by exporting the iPython Notebook as an HTML document. Before exporting the notebook to html, all of the code cells need to have been run so that reviewers can see the final implementation and output. You can then export the notebook by using the menu above and navigating to  \n",
    "**File -> Download as -> HTML (.html)**. Include the finished document along with this notebook as your submission. 

In addition to implementing code, there is a writeup to complete. The writeup should be completed in a separate file, which can be either a markdown file or a pdf document. There is a [write up template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) that can be used to guide the writing process. Completing the code template and writeup template will cover all of the [rubric points](https://review.udacity.com/#!/rubrics/481/view) for this project.

The [rubric](https://review.udacity.com/#!/rubrics/481/view) contains "Stand Out Suggestions" for enhancing the project beyond the minimum requirements. The stand out suggestions are optional. If you decide to pursue the "stand out suggestions", you can include the code in this Ipython notebook and also discuss the results in the writeup file.


>**Note:** Code and Markdown cells can be executed using the **Shift + Enter** keyboard shortcut. In addition, Markdown cells can be edited by typically double-clicking the cell to enter edit mode.

---
## Step 0: Load The Data


```python
# Load pickled data
import pickle
import tensorflow as tf
# TODO: Fill this in based on where you saved the training and testing data

training_file = 'traffic-signs-data/train.p'
validation_file='traffic-signs-data/valid.p'
testing_file = 'traffic-signs-data/test.p'

with open(training_file, mode='rb') as f:
    train = pickle.load(f)
with open(validation_file, mode='rb') as f:
    valid = pickle.load(f)
with open(testing_file, mode='rb') as f:
    test = pickle.load(f)
    
X_train, y_train = train['features'], train['labels']
X_valid, y_valid = valid['features'], valid['labels']
X_test, y_test = test['features'], test['labels']
```

---

## Step 1: Dataset Summary & Exploration

The pickled data is a dictionary with 4 key/value pairs:

- `'features'` is a 4D array containing raw pixel data of the traffic sign images, (num examples, width, height, channels).
- `'labels'` is a 1D array containing the label/class id of the traffic sign. The file `signnames.csv` contains id -> name mappings for each id.
- `'sizes'` is a list containing tuples, (width, height) representing the original width and height the image.
- `'coords'` is a list containing tuples, (x1, y1, x2, y2) representing coordinates of a bounding box around the sign in the image. **THESE COORDINATES ASSUME THE ORIGINAL IMAGE. THE PICKLED DATA CONTAINS RESIZED VERSIONS (32 by 32) OF THESE IMAGES**

Complete the basic data summary below. Use python, numpy and/or pandas methods to calculate the data summary rather than hard coding the results. For example, the [pandas shape method](http://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.shape.html) might be useful for calculating some of the summary results. 

### Provide a Basic Summary of the Data Set Using Python, Numpy and/or Pandas


```python
### Replace each question mark with the appropriate value. 
### Use python, pandas or numpy methods rather than hard coding the results

import numpy as np

# TODO: Number of training examples
n_train = len(X_train)

# TODO: Number of validation examples
n_validation = len(X_valid)

# TODO: Number of testing examples.
n_test = len(X_test)

# TODO: What's the shape of an traffic sign image?
image_shape = X_train.shape[1:4]

# TODO: How many unique classes/labels there are in the dataset.
n_classes = len(np.unique(y_train))

print("Number of training examples =", n_train)
print("Number of validation examples =", n_validation)
print("Number of testing examples =", n_test)
print("Image data shape =", image_shape)
print("Number of classes =", n_classes)
```

    Number of training examples = 34799
    Number of validation examples = 4410
    Number of testing examples = 12630
    Image data shape = (32, 32, 3)
    Number of classes = 43


### Include an exploratory visualization of the dataset

Visualize the German Traffic Signs Dataset using the pickled file(s). This is open ended, suggestions include: plotting traffic sign images, plotting the count of each sign, etc. 

The [Matplotlib](http://matplotlib.org/) [examples](http://matplotlib.org/examples/index.html) and [gallery](http://matplotlib.org/gallery.html) pages are a great resource for doing visualizations in Python.

**NOTE:** It's recommended you start with something simple first. If you wish to do more, come back to it after you've completed the rest of the sections. It can be interesting to look at the distribution of classes in the training, validation and test set. Is the distribution the same? Are there more examples of some classes than others?


```python
### Data exploration visualization code goes here.
### Feel free to use as many code cells as needed.

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import csv
# Visualizations will be shown in the notebook.
%matplotlib inline

#getting all uniques traffic sign images,their indices and frequencies
unique_image_labels,unique_images_start_indices,frequency=np.unique(y_train,return_index=True,return_counts=True)
#print(unique_images_start_indices)
#print(min(frequency))

i=0
pos=[]
for f in frequency:
    #if f<500:
    pos.append(unique_images_start_indices[i])
    i=i+1
print(pos)
print(frequency[3])
```

    [9960, 2220, 31439, 5370, 6810, 12360, 21450, 23730, 15870, 11040, 17130, 8580, 27329, 21810, 29219, 29909, 5010, 30449, 20370, 6630, 25950, 25680, 4500, 1770, 10800, 33449, 1230, 10350, 26849, 10560, 25020, 210, 10140, 26250, 20010, 18930, 900, 4830, 14010, 25410, 4200, 0, 9750]
    1260



```python
#reading the signnames.csv file to get name of each traffic sign

f=open('signnames.csv','rt')
reader=csv.reader(f)

sign_names={}

for row in reader:
    sign_names[row[0]]=row[1]

f.close()
```


```python
#plot all the unique traffic signs in a 8*6 grid figure

plt.figure(1)
i=1

unique_images=[]
for index in unique_images_start_indices:
    plt.subplot(8,6,i)
    #plt.xlabel(str(sign_names[str(y_train[index])]))
    plt.imshow(X_train[index])
    unique_images.append(X_train[index])
    #plt.xlabel(str(sign_names[str(y_train[index])]))
    #figure.savefig('unique_traffic_signs/'+str(unique_image_labels[i-1]))
    i=i+1
         
plt.show()
```


![png](output_10_0.png)



```python
#printing and plotting a pie frequency distribution of each unique traffic symbol
# Pie chart, where the slices will be ordered and plotted counter-clockwise:

fig2, pie_ax1 = plt.subplots(figsize=(300,200))
pie_ax1.pie(sizes, autopct='%1.1f%%',
        shadow=True, startangle=90)
#fig2.savefig('unique_traffic_signs/pie_distribution')
pie_ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
```




    (-0.055000000000000007,
     0.055000000000000007,
     -0.055000000000000007,
     0.055000000000000007)




![png](output_11_1.png)



```python
#bar chart to display classes data distribution
labels = []
sizes = []
indices=[]

#getting all uniques traffic sign images,their indices and frequencies
unique_image_labels,unique_images_start_indices,frequency=np.unique(y_train,return_index=True,return_counts=True)

frequency=np.array(frequency)
classes=[i for i in range(n_classes)]
plt.bar(np.array(classes),frequency)
plt.show()
```


![png](output_12_0.png)


----

## Step 2: Design and Test a Model Architecture

Design and implement a deep learning model that learns to recognize traffic signs. Train and test your model on the [German Traffic Sign Dataset](http://benchmark.ini.rub.de/?section=gtsrb&subsection=dataset).

The LeNet-5 implementation shown in the [classroom](https://classroom.udacity.com/nanodegrees/nd013/parts/fbf77062-5703-404e-b60c-95b78b2f3f9e/modules/6df7ae49-c61c-4bb2-a23e-6527e69209ec/lessons/601ae704-1035-4287-8b11-e2c2716217ad/concepts/d4aca031-508f-4e0b-b493-e7b706120f81) at the end of the CNN lesson is a solid starting point. You'll have to change the number of classes and possibly the preprocessing, but aside from that it's plug and play! 

With the LeNet-5 solution from the lecture, you should expect a validation set accuracy of about 0.89. To meet specifications, the validation set accuracy will need to be at least 0.93. It is possible to get an even higher accuracy, but 0.93 is the minimum for a successful project submission. 

There are various aspects to consider when thinking about this problem:

- Neural network architecture (is the network over or underfitting?)
- Play around preprocessing techniques (normalization, rgb to grayscale, etc)
- Number of examples per label (some have more than others).
- Generate fake data.

Here is an example of a [published baseline model on this problem](http://yann.lecun.com/exdb/publis/pdf/sermanet-ijcnn-11.pdf). It's not required to be familiar with the approach used in the paper but, it's good practice to try to read papers like these.

### Pre-process the Data Set (normalization, grayscale, etc.)

Minimally, the image data should be normalized so that the data has mean zero and equal variance. For image data, `(pixel - 128)/ 128` is a quick way to approximately normalize the data and can be used in this project. 

Other pre-processing steps are optional. You can try different techniques to see if it improves performance. 

Use the code cell (or multiple code cells, if necessary) to implement the first step of your project.


```python
#1.data augmentation

import matplotlib.image as mpimg
from skimage.transform import rotate
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import cv2

plt.imshow(X_train[9960])
```




    <matplotlib.image.AxesImage at 0x7f553e916630>




![png](output_16_1.png)



```python
#def augment_brightness_camera_images(image):
#    image1 = cv2.cvtColor(image,cv2.COLOR_RGB2HSV)
#    random_bright = .25+np.random.uniform()
#    #print(random_bright)
#    image1[:,:,2] = image1[:,:,2]*random_bright
#    image1 = cv2.cvtColor(image1,cv2.COLOR_HSV2RGB)
#    return image1

#def transform_image(img,ang_range,shear_range,trans_range,brightness=0):
#    '''
#    This function transforms images to generate new images.
#    The function takes in following arguments,
#    1- Image
#    2- ang_range: Range of angles for rotation
#    3- shear_range: Range of values to apply affine transform to
#    4- trans_range: Range of values to apply translations over.

#    A Random uniform distribution is used to generate different parameters for transformation

#    '''
    # Rotation

#    ang_rot = np.random.uniform(ang_range)-ang_range/2
#    rows,cols,ch = img.shape    
#    Rot_M = cv2.getRotationMatrix2D((cols/2,rows/2),ang_rot,1)
#
    # Translation
#    tr_x = trans_range*np.random.uniform()-trans_range/2
#    tr_y = trans_range*np.random.uniform()-trans_range/2
#    Trans_M = np.float32([[1,0,tr_x],[0,1,tr_y]])

    # Shear
    #pts1 = np.float32([[5,5],[20,5],[5,20]])

    #pt1 = 5+shear_range*np.random.uniform()-shear_range/2
    #pt2 = 20+shear_range*np.random.uniform()-shear_range/2

    # Brightness

    #pts2 = np.float32([[pt1,5],[pt2,pt1],[5,pt2]])

    #shear_M = cv2.getAffineTransform(pts1,pts2)

#    img = cv2.warpAffine(img,Rot_M,(cols,rows))
#    img = cv2.warpAffine(img,Trans_M,(cols,rows))
    #img = cv2.warpAffine(img,shear_M,(cols,rows))

#    if brightness == 1:
#        img = augment_brightness_camera_images(img)

#    return img
```


```python
# def plot_sample_augmentation_image:
#    image = X_train[25]#mpimg.imread('stopsign.jpg')
#    plt.imshow(image);
#    plt.axis('off');

#    gs1 = gridspec.GridSpec(10, 10)
#    gs1.update(wspace=0.01, hspace=0.02) # set the spacing between axes.
#    plt.figure(figsize=(12,12))
#    for i in range(100):
#        ax1 = plt.subplot(gs1[i])
#        ax1.set_xticklabels([])
#        ax1.set_yticklabels([])
#        ax1.set_aspect('equal')
#        img = transform_image(image,20,10,5,brightness=0)

#        plt.subplot(10,10,i+1)
#        plt.imshow(img)
#        plt.axis('off')

#    plt.show()
```


```python
def insert_augmentetd_data:
    i=0
    print(X_train.shape)

    X=X_train.tolist()
    Y=y_train.tolist()

    for p in pos:
        #print("iteration=",i,"completed upto=",p)
        f=frequency[y_train[p]]

        freq_after_aug=f*int(2500/f )+2500%f -200
        print(f,freq_after_aug)


    i=0
    print(i)
    tot=0
    for p in pos:
        print("iteration=",i,"completed upto=",p)
        f=frequency[y_train[p]]

        freq_after_aug=f*int(2500/f )+2500%f -50
        #if i==10:
         #   break
        tot=f
        #print(tot)

        while tot<freq_after_aug:

            for index in range(f):
                #print(index+p)
                augmented_image=transform_image(X_train[index+p],10,10,5,brightness=0)
                #print(type(augmented_image))
                X.append(augmented_image.tolist())
                Y.append(y_train[index+p])
                tot=tot+1
                if tot==freq_after_aug:
                    print(tot)
                    break
            #tot=tot+f
        i=i+1
    print(X_train.shape)

    print(len(X))

    X_train=np.array(X, dtype=np.uint8)
    X=[]
    y_train=np.array(Y, dtype=np.uint8)
    Y=[]
    print(len(X_train),len(y_train))
    print(len(pos))
    n_train=len(X_train)  
```


```python
#plt a sample image before preprocessing
from skimage import exposure
test_gray=X_train[9960]
plt.imshow(test_gray)
plt.show()

#plot a sample image after grayscaling
test_gray=0.299 * test_gray[ :, :, 0] + 0.587 * test_gray[:, :, 1] + 0.114 * test_gray[ :, :, 2]
test_gray_contrast_enhanced=test_gray
test_gray = test_gray.reshape(test_gray.shape + (1,)) 
plt_grayscale(test_gray)
plt.show()

#plotting an image after local contrast enhancement
test_gray_contrast_enhanced = (test_gray_contrast_enhanced/ 255.).astype(np.float32)
test_gray = exposure.equalize_adapthist(test_gray_contrast_enhanced)
test_gray_contrast_enhanced = test_gray_contrast_enhanced.reshape(test_gray_contrast_enhanced.shape + (1,)) 
plt_grayscale(test_gray_contrast_enhanced)
plt.show()
```


![png](output_20_0.png)



![png](output_20_1.png)


    /home/carnd/anaconda3/envs/carnd-term1/lib/python3.5/site-packages/skimage/util/dtype.py:122: UserWarning: Possible precision loss when converting from float32 to uint16
      .format(dtypeobj_in, dtypeobj_out))



![png](output_20_3.png)



```python
#The lines of this function was heavily influenced by the code from:  
#https://navoshta.com/traffic-signs-classification/
#1.preprocess
from sklearn.utils import shuffle
from skimage import exposure

def preprocess_dataset(X, y = None):
    #Convert to grayscale, e.g. single Y channel
    X = 0.299 * X[:, :, :, 0] + 0.587 * X[:, :, :, 1] + 0.114 * X[:, :, :, 2]
    
    #Scale features to be in [0, 1]
    X = (X / 255.).astype(np.float32)
    #X= (X/128)-1
      
    # Apply localized histogram localization  
    for i in range(X.shape[0]):
        X[i] = exposure.equalize_adapthist(X[i])
        
    #X, y = shuffle(X, y)
    
    # Add a single grayscale channel
    X = X.reshape(X.shape + (1,)) 
    return X, y

# X_train,y_train=preprocess_dataset(X_train,y_train)
```


```python
#plotting grayscale image function
def plt_grayscale(X):
    image=X.squeeze()
    #plt.figure(figsize=(1,1))
    plt.imshow(image,plt.gray())
```


```python
X_valid,y_valid=preprocess_dataset(X_valid,y_valid)
print(X_valid.shape)
print(y_valid.shape)
#plt.imshow(X_train[0],cmap='gray')
#plt.imshow(X_train[9960],cmap='gray')
```

    /home/carnd/anaconda3/envs/carnd-term1/lib/python3.5/site-packages/skimage/util/dtype.py:122: UserWarning: Possible precision loss when converting from float32 to uint16
      .format(dtypeobj_in, dtypeobj_out))


    (4410, 32, 32, 1)
    (4410,)



```python
X_train,y_train=preprocess_dataset(X_train,y_train)
print(X_train.shape)
```

    /home/carnd/anaconda3/envs/carnd-term1/lib/python3.5/site-packages/skimage/util/dtype.py:122: UserWarning: Possible precision loss when converting from float32 to uint16
      .format(dtypeobj_in, dtypeobj_out))


    (34799, 32, 32, 1)



```python
X_test,y_test=preprocess_dataset(X_test,y_test)
print(X_test.shape) 
```

    /home/carnd/anaconda3/envs/carnd-term1/lib/python3.5/site-packages/skimage/util/dtype.py:122: UserWarning: Possible precision loss when converting from float32 to uint16
      .format(dtypeobj_in, dtypeobj_out))


    (12630, 32, 32, 1)



```python
#to save the processed data in pickle

#import pickle
#pickle_X_train = open("X_preprocessed.pickle","wb")
#pickle_y_train = open("Y_preprocessed.pickle","wb")
#pickle.dump(X_train, pickle_X_train)
#pickle.dump(y_train, pickle_y_train)
#pickle_X_train.close()
#pickle_y_train.close()
```


```python
#pickle_X_valid = open("X_valid_preprocessed.pickle","wb")
#pickle_y_valid = open("Y_valid_preprocessed.pickle","wb")
#pickle.dump(X_valid, pickle_X_valid)
#pickle.dump(y_valid, pickle_y_valid)
#pickle_X_valid.close()
#pickle_y_valid.close()

#pickle_X_test = open("X_test_preprocessed.pickle","wb")
#pickle_y_test = open("Y_test_preprocessed.pickle","wb")
#pickle.dump(X_test, pickle_X_test)
#pickle.dump(y_test, pickle_y_test)
#pickle_X_test.close()
#pickle_y_test.close()
```


```python
#load the processed pickle files
#from sklearn.utils import shuffle
#X_train = pickle.load( open( "X_preprocessed.pickle", "rb" ) )
#y_train = pickle.load( open( "Y_preprocessed.pickle", "rb" ) )
#X_valid = pickle.load( open( "X_valid_preprocessed.pickle", "rb" ) )
#X_valid = pickle.load( open( "X_valid_preprocessed.pickle", "rb" ) )
```

### Model Architecture


```python
### Define your architecture here.
### Feel free to use as many code cells as needed.

#initialize weights and biases
import tensorflow as tf
from tensorflow.contrib.layers import flatten

mu = 0
sigma = 0.1
print("hello")
print(n_classes)

weights = {
    'wc1': tf.Variable(tf.truncated_normal((5, 5, 1, 6),mu,sigma)),
    'wc2': tf.Variable(tf.truncated_normal((5, 5, 6, 16),mu,sigma)),
    'wd1': tf.Variable(tf.truncated_normal((5*5*16, 120),mu,sigma)),
    'wd2': tf.Variable(tf.truncated_normal((120, 84),mu,sigma)),
    'out': tf.Variable(tf.truncated_normal((84, n_classes),mu,sigma))}

biases = {
    'bc1': tf.Variable(tf.random_normal([6])),
    'bc2': tf.Variable(tf.random_normal([16])),
    'bd1': tf.Variable(tf.random_normal([120])),
    'bd2': tf.Variable(tf.random_normal([84])),
    'out': tf.Variable(tf.random_normal([n_classes]))}
```

    hello
    43



```python
def conv2d(x, W, b,strides,dropout=1):
    x = tf.nn.conv2d(x, W, strides=[1, strides, strides, 1],padding='VALID')
    x = tf.nn.bias_add(x, b)
    x = tf.nn.relu(x)
    return tf.nn.dropout(x,dropout)

def maxpool2d(x, k=2):
    return tf.nn.max_pool(
        x,
        ksize=[1, k, k, 1],
        strides=[1, k, k, 1],
        padding='VALID')
```


```python
def LeNet(x,keep_prob):    
    # Arguments used for tf.truncated_normal, randomly defines variables for the weights and biases for each layer
    mu = 0
    sigma = 0.1
    
    keep_probs=[]
    if keep_prob=="True":
        keep_probs=[0.7,0.8,0.7,0.8]
    else :
        keep_probs=[1,1,1,1]
    # TODO: Layer 1: Convolutional. Input = 32x32x1. Output = 28x28x6.
    conv1 = conv2d(x, weights['wc1'], biases['bc1'],1,keep_probs[0])

    #TODO: Activation.
    #conv1=tf.nn.relu(conv1)

    # TODO: Pooling. Input = 28x28x6. Output = 14x14x6.
    conv1 = maxpool2d(conv1, k=2)

    # TODO: Layer 2: Convolutional. Output = 10x10x16.
    conv2 = conv2d(conv1, weights['wc2'], biases['bc2'],1,keep_probs[1])
    
    # TODO: Activation.
    #conv2=tf.nn.relu(conv1)

    # TODO: Pooling. Input = 10x10x16. Output = 5x5x16.
    conv2 = maxpool2d(conv2, k=2)
    
    # TODO: Flatten. Input = 5x5x16. Output = 400.
    fc1 = tf.reshape(conv2, [-1, weights['wd1'].get_shape().as_list()[0]])
    
    # TODO: Layer 3: Fully Connected. Input = 400. Output = 120.
    fc1 = tf.add(tf.matmul(fc1, weights['wd1']), biases['bd1'])
    
    # TODO: Activation.
    fc1 = tf.nn.relu(fc1)
    fc1 = tf.nn.dropout(fc1,keep_probs[0])

    # TODO: Layer 4: Fully Connected. Input = 120. Output = 84.
    fc2 = tf.add(tf.matmul(fc1, weights['wd2']), biases['bd2'])
    
    # TODO: Activation.
    fc2 = tf.nn.relu(fc2)
    fc2 = tf.nn.dropout(fc2, keep_probs[1])

    # TODO: Layer 5: Fully Connected. Input = 84. Output = 10.
    logits = tf.add(tf.matmul(fc2, weights['out']), biases['out'])
    
    return logits
```

### Train, Validate and Test the Model

A validation set can be used to assess how well the model is performing. A low accuracy on the training and validation
sets imply underfitting. A high accuracy on the training set but low accuracy on the validation set implies overfitting.


```python
### Train your model here.
### Calculate and report the accuracy on the training and validation set.
### Once a final model architecture is selected, 
### the accuracy on the test set should be calculated and reported as well.
### Feel free to use as many code cells as needed.

```


```python
#computation graph

x = tf.placeholder(tf.float32, (None, 32, 32, 1))
y = tf.placeholder(tf.int32, (None))
one_hot_y = tf.one_hot(y, 43)
keep_prob = tf.placeholder(tf.bool)

rate = 0.001

logits = LeNet(x,keep_prob)
cross_entropy = tf.nn.softmax_cross_entropy_with_logits(labels=one_hot_y, logits=logits)
loss_operation = tf.reduce_mean(cross_entropy)
optimizer = tf.train.AdamOptimizer(learning_rate = rate)
training_operation = optimizer.minimize(loss_operation)
```


```python
#model evaluation
## Train the Model
correct_prediction = tf.equal(tf.argmax(logits, 1), tf.argmax(one_hot_y, 1))
accuracy_operation = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
saver = tf.train.Saver()
train_loss_history = []
valid_loss_history = []
EPOCHS = 40
BATCH_SIZE = 256

def evaluate(X_data, y_data):
    num_examples = len(X_data)
    total_accuracy = 0
    total_loss=0
    sess = tf.get_default_session()
    for offset in range(0, num_examples, BATCH_SIZE):
        batch_x, batch_y = X_data[offset:offset+BATCH_SIZE], y_data[offset:offset+BATCH_SIZE] 
        loss, accuracy = sess.run([loss_operation, accuracy_operation], feed_dict={x: batch_x, y: batch_y,keep_prob:False})
        total_accuracy += (accuracy * len(batch_x))
        total_loss += (loss * len(batch_x))
    return total_loss/num_examples, total_accuracy/num_examples
```


```python
#train the model

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    num_examples = len(X_train)
    
    print("Training...")
    print()
    for i in range(EPOCHS):
        X_train, y_train = shuffle(X_train, y_train)
        for offset in range(0, num_examples, BATCH_SIZE):
            end = offset + BATCH_SIZE
            batch_x, batch_y = X_train[offset:end], y_train[offset:end]
            sess.run(training_operation, feed_dict={x: batch_x, y: batch_y,keep_prob:True})
            
        validation_loss, validation_accuracy = evaluate(X_valid, y_valid)
        valid_loss_history.append(validation_loss)
        train_loss, train_accuracy = evaluate(X_train, y_train)
        train_loss_history.append(train_loss)
        print("EPOCH {} ...".format(i+1))
        print("Validation Accuracy = {:.3f}".format(validation_accuracy))
        print("Training Accuracy = {:.3f}".format(train_accuracy))
        print()
    
    saver.save(sess, './lenet')
    print("Model saved")
```

    Training...
    
    EPOCH 1 ...
    Validation Accuracy = 0.479
    Training Accuracy = 0.510
    
    EPOCH 2 ...
    Validation Accuracy = 0.769
    Training Accuracy = 0.827
    
    EPOCH 3 ...
    Validation Accuracy = 0.819
    Training Accuracy = 0.864
    
    EPOCH 4 ...
    Validation Accuracy = 0.877
    Training Accuracy = 0.917
    
    EPOCH 5 ...
    Validation Accuracy = 0.887
    Training Accuracy = 0.937
    
    EPOCH 6 ...
    Validation Accuracy = 0.888
    Training Accuracy = 0.946
    
    EPOCH 7 ...
    Validation Accuracy = 0.892
    Training Accuracy = 0.958
    
    EPOCH 8 ...
    Validation Accuracy = 0.913
    Training Accuracy = 0.967
    
    EPOCH 9 ...
    Validation Accuracy = 0.919
    Training Accuracy = 0.969
    
    EPOCH 10 ...
    Validation Accuracy = 0.925
    Training Accuracy = 0.975
    
    EPOCH 11 ...
    Validation Accuracy = 0.927
    Training Accuracy = 0.979
    
    EPOCH 12 ...
    Validation Accuracy = 0.934
    Training Accuracy = 0.983
    
    EPOCH 13 ...
    Validation Accuracy = 0.914
    Training Accuracy = 0.978
    
    EPOCH 14 ...
    Validation Accuracy = 0.927
    Training Accuracy = 0.986
    
    EPOCH 15 ...
    Validation Accuracy = 0.929
    Training Accuracy = 0.988
    
    EPOCH 16 ...
    Validation Accuracy = 0.931
    Training Accuracy = 0.988
    
    EPOCH 17 ...
    Validation Accuracy = 0.921
    Training Accuracy = 0.989
    
    EPOCH 18 ...
    Validation Accuracy = 0.937
    Training Accuracy = 0.994
    
    EPOCH 19 ...
    Validation Accuracy = 0.936
    Training Accuracy = 0.992
    
    EPOCH 20 ...
    Validation Accuracy = 0.935
    Training Accuracy = 0.995
    
    EPOCH 21 ...
    Validation Accuracy = 0.932
    Training Accuracy = 0.996
    
    EPOCH 22 ...
    Validation Accuracy = 0.934
    Training Accuracy = 0.994
    
    EPOCH 23 ...
    Validation Accuracy = 0.932
    Training Accuracy = 0.997
    
    EPOCH 24 ...
    Validation Accuracy = 0.935
    Training Accuracy = 0.996
    
    EPOCH 25 ...
    Validation Accuracy = 0.935
    Training Accuracy = 0.996
    
    EPOCH 26 ...
    Validation Accuracy = 0.935
    Training Accuracy = 0.994
    
    EPOCH 27 ...
    Validation Accuracy = 0.940
    Training Accuracy = 0.999
    
    EPOCH 28 ...
    Validation Accuracy = 0.935
    Training Accuracy = 0.998
    
    EPOCH 29 ...
    Validation Accuracy = 0.941
    Training Accuracy = 0.998
    
    EPOCH 30 ...
    Validation Accuracy = 0.940
    Training Accuracy = 0.996
    
    EPOCH 31 ...
    Validation Accuracy = 0.937
    Training Accuracy = 0.999
    
    EPOCH 32 ...
    Validation Accuracy = 0.939
    Training Accuracy = 0.999
    
    EPOCH 33 ...
    Validation Accuracy = 0.929
    Training Accuracy = 0.993
    
    EPOCH 34 ...
    Validation Accuracy = 0.945
    Training Accuracy = 0.999
    
    EPOCH 35 ...
    Validation Accuracy = 0.944
    Training Accuracy = 0.998
    
    EPOCH 36 ...
    Validation Accuracy = 0.943
    Training Accuracy = 0.997
    
    EPOCH 37 ...
    Validation Accuracy = 0.934
    Training Accuracy = 0.995
    
    EPOCH 38 ...
    Validation Accuracy = 0.930
    Training Accuracy = 0.996
    
    EPOCH 39 ...
    Validation Accuracy = 0.941
    Training Accuracy = 1.000
    
    EPOCH 40 ...
    Validation Accuracy = 0.943
    Training Accuracy = 1.000
    
    Model saved



```python
#training , validation loss plot
import matplotlib.pyplot as plt
loss_plot = plt.subplot(2,1,1)
loss_plot.set_title('Loss')
loss_plot.plot(train_loss_history, 'r', label='Training Loss')
loss_plot.plot(valid_loss_history, 'b', label='Validation Loss')
loss_plot.set_xlim([0, EPOCHS])
loss_plot.legend(loc=4)
plt.show()
```


![png](output_39_0.png)



```python
#evaluate the model 

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    saver2 = tf.train.import_meta_graph('./lenet.meta')
    saver2.restore(sess, "./lenet")
    test_loss,test_accuracy = evaluate(X_test, y_test)
    print("Test Set Accuracy = {:.3f}".format(test_accuracy))
```

    Test Set Accuracy = 0.933


---

## Step 3: Test a Model on New Images

To give yourself more insight into how your model is working, download at least five pictures of German traffic signs from the web and use your model to predict the traffic sign type.

You may find `signnames.csv` useful as it contains mappings from the class id (integer) to the actual sign name.

### Load and Output the Images


```python

```


```python
### Load the images and plot them here.
### Feel free to use as many code cells as needed.

import imageio
import matplotlib.pyplot as plt
import numpy as np

im1= imageio.imread('final image testing/turn-right-ahead.jpeg') #image is actually of go straight or right
im2= imageio.imread('final image testing/ahead only 17.jpeg')
im3= imageio.imread('final image testing/keep right 39.jpeg')
im4= imageio.imread('final image testing/no entry 17.jpeg')
im5= imageio.imread('final image testing/roadwork25.jpeg')
im6= imageio.imread('final image testing/priority_road.jpeg')
#im7= imageio.imread('final image testing/roundabout2.jpeg')

print("verifying shape of each image to be 32*32")
print(im1.shape,im2.shape,im3.shape,im4.shape,im5.shape,im6.shape)

#converting the images to numpy array
X_downloaded=[list(im1),list(im2),list(im3),list(im4),list(im5),list(im6)]
X_downloaded=np.array(X_downloaded)

#hardcoding the labels of each image, as mentioned in signnames.csv
y_downloaded=np.array([36,35,38,17,25,12])

for i in range(len(X_downloaded)):
    plt.subplot(6,1,i+1)
    plt.imshow(X_downloaded[i])
    plt.show()
    print(sign_names[str(y_downloaded[i])])
plt.show()
```

    verifying shape of each image to be 32*32
    (32, 32, 3) (32, 32, 3) (32, 32, 3) (32, 32, 3) (32, 32, 3) (32, 32, 3)



![png](output_44_1.png)


    Go straight or right



![png](output_44_3.png)


    Ahead only



![png](output_44_5.png)


    Keep right



![png](output_44_7.png)


    No entry



![png](output_44_9.png)


    Road work



![png](output_44_11.png)


    Priority road



```python
#X_downloaded,y_downloaded=preprocess_dataset(X_downloaded,y_downloaded)
print(X_downloaded.shape,y_downloaded.shape)
```

    (6, 32, 32, 3) (6,)


### Predict the Sign Type for Each Image


```python
### Run the predictions here and use the model to output the prediction for each image.
### Make sure to pre-process the images with the same pre-processing pipeline used earlier.
### Feel free to use as many code cells as needed.
import tensorflow as tf

#x = tf.placeholder(tf.float32, (None, 32, 32, 1))
#y = tf.placeholder(tf.int32, (None))

#one_hot_y = tf.one_hot(y, 43)
#keep_prob = tf.placeholder(tf.bool)
#logits = LeNet(x,keep_prob)
#cross_entropy = tf.nn.softmax_cross_entropy_with_logits(labels=one_hot_y, logits=logits)

#preprocessing of downloaded images
X_downloaded,y_downloaded=preprocess_dataset(X_downloaded,y_downloaded)
print(X_downloaded.shape,y_downloaded.shape)


softmax_logits=tf.nn.softmax(logits)
top_k=tf.nn.top_k(softmax_logits,k=5)
#loss_operation = tf.reduce_mean(cross_entropy)


with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    saver3 = tf.train.import_meta_graph('./lenet.meta')
    saver3.restore(sess, "./lenet")
    custom_loss,custom_accuracy = evaluate(X_downloaded, y_downloaded)
    print("Test Set Accuracy = {:.3f}".format(custom_accuracy))
    #softmax_logits1=sess.run(softmax_logits,feed_dict={})
    top_ks=sess.run(top_k,feed_dict={x:X_downloaded,keep_prob:False})
    print(softmax_logits)
    print(top_ks)
    
print("labels :",y_downloaded)
#custom_loss, custom_accuracy = evaluate(X_downloaded, y_downloaded)
#print(custom_loss,custom_accuracy) 
#[33,35,38,17,14,1,40])
```

    /home/carnd/anaconda3/envs/carnd-term1/lib/python3.5/site-packages/skimage/util/dtype.py:122: UserWarning: Possible precision loss when converting from float32 to uint16
      .format(dtypeobj_in, dtypeobj_out))


    (6, 32, 32, 1) (6,)
    Test Set Accuracy = 0.833
    Tensor("Softmax:0", shape=(?, 43), dtype=float32)
    TopKV2(values=array([[  9.99975204e-01,   2.08424917e-05,   3.86090369e-06,
              5.89965836e-08,   5.73386103e-08],
           [  9.99958515e-01,   3.76254247e-05,   3.86981583e-06,
              2.38777731e-09,   7.99019961e-10],
           [  9.99970913e-01,   2.16922508e-05,   7.29756312e-06,
              6.75543959e-08,   5.37656639e-08],
           [  1.00000000e+00,   6.37948627e-09,   5.33464870e-11,
              1.11242699e-12,   6.42045228e-13],
           [  5.14833868e-01,   4.02585268e-01,   7.70603940e-02,
              5.50515996e-03,   6.60882824e-06],
           [  9.99880672e-01,   1.06838947e-04,   1.24956405e-05,
              9.22145471e-09,   1.14371224e-09]], dtype=float32), indices=array([[36, 25, 12, 35, 18],
           [35, 13, 12, 36, 25],
           [38, 41, 20,  9, 28],
           [17, 14, 13, 22,  1],
           [25, 22, 29, 31, 23],
           [15, 12, 13,  9, 32]], dtype=int32))
    labels : [36 35 38 17 25 12]


### Analyze Performance


```python
### Calculate the accuracy for these 5 new images. 
### For example, if the model predicted 1 out of 5 signs correctly, it's 20% accurate on these new images.

top_5_probabilities=top_ks[0]
top_5_class_labels=top_ks[1]

print("original labels :",y_downloaded)
#print((top_5_probabilities))
#print((top_5_class_labels))


print("\nACTUAL_TRAFFIC_SIGN_NAME\t  PREDICTED_TRAFFIC_SIGN_NAME\t\n")
i=0
for original_label in y_downloaded:
    predicted_label=top_5_class_labels[i][0]
    
    #plt.subplot(7,2,i)
    #plt.imshow(X_downloaded[original_label])
    #plt.imshow()
    print(sign_names[str(original_label)],"\t\t\t",sign_names[str(predicted_label)] )
    #plt.show()
    i=i+1
```

    original labels : [36 35 38 17 25 12]
    
    ACTUAL_TRAFFIC_SIGN_NAME	  PREDICTED_TRAFFIC_SIGN_NAME	
    
    Go straight or right 			 Go straight or right
    Ahead only 			 Ahead only
    Keep right 			 Keep right
    No entry 			 No entry
    Road work 			 Road work
    Priority road 			 No vehicles


### Output Top 5 Softmax Probabilities For Each Image Found on the Web

For each of the new images, print out the model's softmax probabilities to show the **certainty** of the model's predictions (limit the output to the top 5 probabilities for each image). [`tf.nn.top_k`](https://www.tensorflow.org/versions/r0.12/api_docs/python/nn.html#top_k) could prove helpful here. 

The example below demonstrates how tf.nn.top_k can be used to find the top k predictions for each image.

`tf.nn.top_k` will return the values and indices (class ids) of the top k predictions. So if k=3, for each sign, it'll return the 3 largest probabilities (out of a possible 43) and the correspoding class ids.

Take this numpy array as an example. The values in the array represent predictions. The array contains softmax probabilities for five candidate images with six possible classes. `tf.nn.top_k` is used to choose the three classes with the highest probability:

```
# (5, 6) array
a = np.array([[ 0.24879643,  0.07032244,  0.12641572,  0.34763842,  0.07893497,
         0.12789202],
       [ 0.28086119,  0.27569815,  0.08594638,  0.0178669 ,  0.18063401,
         0.15899337],
       [ 0.26076848,  0.23664738,  0.08020603,  0.07001922,  0.1134371 ,
         0.23892179],
       [ 0.11943333,  0.29198961,  0.02605103,  0.26234032,  0.1351348 ,
         0.16505091],
       [ 0.09561176,  0.34396535,  0.0643941 ,  0.16240774,  0.24206137,
         0.09155967]])
```

Running it through `sess.run(tf.nn.top_k(tf.constant(a), k=3))` produces:

```
TopKV2(values=array([[ 0.34763842,  0.24879643,  0.12789202],
       [ 0.28086119,  0.27569815,  0.18063401],
       [ 0.26076848,  0.23892179,  0.23664738],
       [ 0.29198961,  0.26234032,  0.16505091],
       [ 0.34396535,  0.24206137,  0.16240774]]), indices=array([[3, 0, 5],
       [0, 1, 4],
       [0, 5, 1],
       [1, 3, 5],
       [1, 4, 3]], dtype=int32))
```

Looking just at the first row we get `[ 0.34763842,  0.24879643,  0.12789202]`, you can confirm these are the 3 largest probabilities in `a`. You'll also notice `[3, 0, 5]` are the corresponding indices.


```python
### Print out the top five softmax probabilities for the predictions on the German traffic sign images found on the web. 
### Feel free to use as many code cells as needed.

print("ACTUAL_label\t TOP_5_PREDICTED_LABELS and PROBABILITIES\t\n")

#percentage_probs=list(top_5_probabilities)

#i=0
#for prob in percentage_probs:
#    percentage_probs=float(top_5_probabilities[i])
#    i=i+i

#print(percentage_probs)

i=0
for original_label in y_downloaded:
    predicted_label=top_5_class_labels[i][0]
    print(original_label,"\t\t",top_5_class_labels[i])
    print("top 5 probabilities=",top_5_probabilities[i])
    print("\n\n")
    i=i+1
```

    ACTUAL_label	 TOP_5_PREDICTED_LABELS and PROBABILITIES	
    
    36 		 [36 25 12 35 18]
    top 5 probabilities= [  9.99975204e-01   2.08424917e-05   3.86090369e-06   5.89965836e-08
       5.73386103e-08]
    
    
    
    35 		 [35 13 12 36 25]
    top 5 probabilities= [  9.99958515e-01   3.76254247e-05   3.86981583e-06   2.38777731e-09
       7.99019961e-10]
    
    
    
    38 		 [38 41 20  9 28]
    top 5 probabilities= [  9.99970913e-01   2.16922508e-05   7.29756312e-06   6.75543959e-08
       5.37656639e-08]
    
    
    
    17 		 [17 14 13 22  1]
    top 5 probabilities= [  1.00000000e+00   6.37948627e-09   5.33464870e-11   1.11242699e-12
       6.42045228e-13]
    
    
    
    25 		 [25 22 29 31 23]
    top 5 probabilities= [  5.14833868e-01   4.02585268e-01   7.70603940e-02   5.50515996e-03
       6.60882824e-06]
    
    
    
    12 		 [15 12 13  9 32]
    top 5 probabilities= [  9.99880672e-01   1.06838947e-04   1.24956405e-05   9.22145471e-09
       1.14371224e-09]
    
    
    


### Project Writeup

Once you have completed the code implementation, document your results in a project writeup using this [template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) as a guide. The writeup can be in a markdown or pdf file. 

> **Note**: Once you have completed all of the code implementations and successfully answered each question above, you may finalize your work by exporting the iPython Notebook as an HTML document. You can do this by using the menu above and navigating to  \n",
    "**File -> Download as -> HTML (.html)**. Include the finished document along with this notebook as your submission.

---

## Step 4 (Optional): Visualize the Neural Network's State with Test Images

 This Section is not required to complete but acts as an additional excersise for understaning the output of a neural network's weights. While neural networks can be a great learning device they are often referred to as a black box. We can understand what the weights of a neural network look like better by plotting their feature maps. After successfully training your neural network you can see what it's feature maps look like by plotting the output of the network's weight layers in response to a test stimuli image. From these plotted feature maps, it's possible to see what characteristics of an image the network finds interesting. For a sign, maybe the inner network feature maps react with high activation to the sign's boundary outline or to the contrast in the sign's painted symbol.

 Provided for you below is the function code that allows you to get the visualization output of any tensorflow weight layer you want. The inputs to the function should be a stimuli image, one used during training or a new one you provided, and then the tensorflow variable name that represents the layer's state during the training process, for instance if you wanted to see what the [LeNet lab's](https://classroom.udacity.com/nanodegrees/nd013/parts/fbf77062-5703-404e-b60c-95b78b2f3f9e/modules/6df7ae49-c61c-4bb2-a23e-6527e69209ec/lessons/601ae704-1035-4287-8b11-e2c2716217ad/concepts/d4aca031-508f-4e0b-b493-e7b706120f81) feature maps looked like for it's second convolutional layer you could enter conv2 as the tf_activation variable.

For an example of what feature map outputs look like, check out NVIDIA's results in their paper [End-to-End Deep Learning for Self-Driving Cars](https://devblogs.nvidia.com/parallelforall/deep-learning-self-driving-cars/) in the section Visualization of internal CNN State. NVIDIA was able to show that their network's inner weights had high activations to road boundary lines by comparing feature maps from an image with a clear path to one without. Try experimenting with a similar test to show that your trained network's weights are looking for interesting features, whether it's looking at differences in feature maps from images with or without a sign, or even what feature maps look like in a trained network vs a completely untrained one on the same sign image.

<figure>
 <img src="visualize_cnn.png" width="380" alt="Combined Image" />
 <figcaption>
 <p></p> 
 <p style="text-align: center;"> Your output should look something like this (above)</p> 
 </figcaption>
</figure>
 <p></p> 



```python
### Visualize your network's feature maps here.
### Feel free to use as many code cells as needed.

# image_input: the test image being fed into the network to produce the feature maps
# tf_activation: should be a tf variable name used during your training procedure that represents the calculated state of a specific weight layer
# activation_min/max: can be used to view the activation contrast in more detail, by default matplot sets min and max to the actual min and max values of the output
# plt_num: used to plot out multiple different weight feature map sets on the same block, just extend the plt number for each new feature map entry

def outputFeatureMap(image_input, tf_activation, activation_min=-1, activation_max=-1 ,plt_num=1):
    # Here make sure to preprocess your image_input in a way your network expects
    # with size, normalization, ect if needed
    # image_input =
    # Note: x should be the same name as your network's tensorflow data placeholder variable
    # If you get an error tf_activation is not defined it may be having trouble accessing the variable from inside a function
    activation = tf_activation.eval(session=sess,feed_dict={x : image_input})
    featuremaps = activation.shape[3]
    plt.figure(plt_num, figsize=(15,15))
    for featuremap in range(featuremaps):
        plt.subplot(6,8, featuremap+1) # sets the number of feature maps to show on each row and column
        plt.title('FeatureMap ' + str(featuremap)) # displays the feature map number
        if activation_min != -1 & activation_max != -1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmin =activation_min, vmax=activation_max, cmap="gray")
        elif activation_max != -1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmax=activation_max, cmap="gray")
        elif activation_min !=-1:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", vmin=activation_min, cmap="gray")
        else:
            plt.imshow(activation[0,:,:, featuremap], interpolation="nearest", cmap="gray")
```
