﻿## Writeup Template

---
**Advanced Lane Finding Project**

The goals / steps of this project are the following:

* Compute the camera calibration matrix and distortion coefficients given a set of chessboard images.
* Apply a distortion correction to raw images.
* Use color transforms, gradients, etc., to create a thresholded binary image.
* Apply a perspective transform to rectify binary image ("birds-eye view").
* Detect lane pixels and fit to find the lane boundary.
* Determine the curvature of the lane and vehicle position with respect to center.
* Warp the detected lane boundaries back onto the original image.
* Output visual display of the lane boundaries and numerical estimation of lane curvature and vehicle position.

[//]: # (Image References)

[image1]: ./examples/undistort_output.png "Undistorted"
[image2]: ./test_images/test1.jpg "Road Transformed"
[image3]: ./examples/binary_combo_example.jpg "Binary Example"
[image4]: ./examples/warped_straight_lines.jpg "Warp Example"
[image5]: ./examples/color_fit_lines.jpg "Fit Visual"
[image6]: ./examples/example_output.jpg "Output"
[video1]: ./project_video.mp4 "Video"

## [Rubric](https://review.udacity.com/#!/rubrics/571/view) Points

### Here I will consider the rubric points individually and describe how I addressed each point in my implementation.  

# Writeup / README

You're reading it!
---
### Note
For this project, i have used a modularized coding style. The project consists of the following python files:

1. calibrate_and_undistort.py
2. grad_thresholding.py
3. color_thresholding.py
4. color_and_grad_combined.py
5. topview.py
6. sliding_window.py
7. pipeline.py

The code can be run in 2 ways, either:<br>
	1. import pipeline<br/>
	   pipeline.process_video()
	   or <br>
	   2. Run all cells in Advance_Lane_Finding.ipynb

### Camera Calibration

#### 1. Briefly state how you computed the camera matrix and distortion coefficients. Provide an example of a distortion corrected calibration image.

The code for this step is contained in the python file 'calibrate_and_undistort.py' (function calibrate_camera() lines 67-77)  

I started by preparing "object points", which will be the (x, y, z) coordinates of the chessboard corners in the world. Here I am assuming the chessboard is fixed on the (x, y) plane at z=0, such that the object points are the same for each calibration image.  Thus, `objp` is just a replicated array of coordinates, and `objpoints` will be appended with a copy of it every time I successfully detect all chessboard corners in a test image.  `imgpoints` will be appended with the (x, y) pixel position of each of the corners in the image plane with each successful chessboard detection.  

I then used the output `objpoints` and `imgpoints` to compute the camera calibration and distortion coefficients using the `cv2.calibrateCamera()` function.  I applied this distortion correction to the test image using the `cv2.undistort()` function and obtained this result: 

![png](output\_1\_1.png)

### Pipeline (single images)

#### 1. Provide an example of a distortion-corrected image.

To demonstrate this step, I will describe how I apply the distortion correction to one of the test images like this one:

![png](output\_2\_0.png)

#### 2. Describe how (and identify where in your code) you used color transforms, gradients or other methods to create a thresholded binary image.  Provide an example of a binary image result.

I first analysed gradients and color thresholds separately.
Here are two eaxmples from gradient analysis (complete output list in output_images folder)

![png](output\_3\_0.png)
![png](output\_3\_1.png)

From above,i  found sobel_x and direction thresholds performing better in finding lane lines, so i used a combination of both, and ignored others.
sobel_x threshold=((20, 200), because lane lines are almost vertical(normally, and more if perspective transform is used before thresholding) <br>
direction_threshold = (0.5, 1.5) ,roughly selects angles between 30 and 90 degree
`(grad_thresholding.get_grad_combined(image), 150-175 grad_thresholding.py)`

Then i analysed the color channels, as shown in

![png](output\_4\_0.png)
![png](output\_4\_1.png)

From above i found the S_channel to be performing better in detecting lanes,
I used a threshold range (130, 255), as the lane lines had a good saturation,except at shadows.
(color_thresholding.py (22-45)

I finally combined color and gradient thresholds to generate a binary image (thresholding steps at lines 64 through 85 in `color_and_grad_combined.py`).  Here's an example of my output for this step.  

![png](output\_5\_0.png)
![png](output\_5\_6.png)

`when	i used this thresholding in the video, i found it to be not performing well in shadows, so i used the L channel(threshold(100-255)) to select only those pixels that are bright enough`

#### 3. Describe how (and identify where in your code) you performed a perspective transform and provide an example of a transformed image.

The code for my perspective transform includes 2 functions called `find_Perspective_Matrix()` and `get_top_view()`, which appears in lines 10-44 and 69 -74 in the file `topview.py` .  I chose to hard-code the source and destination points as the following.


| Source        | Destination   | 
|:-------------:|:-------------:| 
| 210, 720      | 310, 720        | 
| 1115, 720      | 910, 720      |
| 725, 470| 910, 1      |
| 570, 470      | 310, 1        |

I verified that my perspective transform was working as expected by plotting both the original and warped images together

![png](output\_6\_1.png)
![png](output\_6\_4.png)

#### 4. Describe how (and identify where in your code) you identified lane-line pixels and fit their positions with a polynomial?

I did this in lines 8 through 85 in my code in `sliding_window.py`

I used the histogram technique(taking sum of each column of the image) to identify the base(x-coordinate) of the lane lines(which are nothing but the 2 peaks in the histogram). Then i used use a sliding window, placed around the line centers, to find and follow the lines up to the top of the frame. As each window is slide up acc. to the avg. value of the co-ordinates of the non-zero pixels in the current window, so if the lane line is curved, the averaged center points also shifts,and accordingly the window also shifts.

 Then,i  fit my lane lines with a 2nd order polynomial :

![png](output\_7\_0.png)
![png](output\_7\_4.png)

#### 5. Describe how (and identify where in your code) you calculated the radius of curvature of the lane and the position of the vehicle with respect to center.

I did this in lines 117 through 153 in my code in `sliding_window.py`
I used the formula given in the classroom, to find the radius of curvature.
For vehicle position, i got the x coordinate of this curve given the y at bottom of the frame,then i got the midpoint of the two curves and subtracted that from the midpoint of the image ( where the vehicle is located), and then converted the values from pixels to metre.

#### 6. Provide an example image of your result plotted back down onto the road such that the lane area is identified clearly.

I implemented this step in lines 110 through 113 in my code in `sliding_window.py` .  Here is an example of my final output (taken from a video frame):

![png](video.png)

---

### Pipeline (video)

#### 1. Provide a link to your final video output.  Your pipeline should perform reasonably well on the entire project video (wobbly lines are ok but no catastrophic failures that would cause the car to drive off the road!).

Here's a [link to my video result](https://github.com/anupamhap/CarND-Advance-Lane-Lines-Submission/raw/master/test_output_video/project_video_output.mp4)

---

### Discussion

#### 1. Briefly discuss any problems / issues you faced in your implementation of this project.  Where will your pipeline likely fail?  What could you do to make it more robust?

### Challenges faced
At first, my pipeline failed at 2 frame intervals from the video. I took subclips at those intervals, and then tuned the parameters, to make it work. The main issues were,
presence of too much shadow at some frames, and presence of noise towards the left and right sides of the image.
For shadows, once i used L channel and tuned it properly, i was able make this clip work.
For noise reduction, I used  a region of mask to improve the lane detection.

### Further improvements
1. We may end up with very bad frames, where no lanes might be visible, Past-frame averaging can be used at those frames.
2. Using sanity checks to verify if the lane detections makes sense


