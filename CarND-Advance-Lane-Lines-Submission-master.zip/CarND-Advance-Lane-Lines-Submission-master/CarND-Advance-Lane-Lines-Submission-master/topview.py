import cv2
import numpy as np
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import glob

M=None
Minv=None

def find_Perspective_Matrix():
    img=mpimg.imread('test_images/straight_lines1.jpg')
    print(img.shape)
    #plt.imshow(img)
    #plt.show()

    # source points , a trapezoidal area is selected
    sbleft=[210,720]
    sbright=[1115,720]
    stright=[725,470]
    stleft=[570,470]

    #stright=[673,444]
    #stleft=[601,444]

    src_vertices=np.array([sbleft,sbright,stright,stleft],np.int32)
    src_pts=src_vertices.reshape((-1,1,2))
    img_copy=np.copy(img)
    cv2.polylines(img_copy,[src_pts],True,(0,255,0),thickness=3)
    #plt.imshow(img_copy)
    #plt.show()

    # Destination points
    d_bleft = [310, 720]
    d_bright = [910, 720]
    d_tright = [910, 1]
    d_tleft = [310, 1]

    src=np.float32([sbleft,sbright,stright,stleft])
    dst = np.float32([d_bleft, d_bright, d_tright, d_tleft])

    global M
    global Minv
    M = cv2.getPerspectiveTransform(src, dst)
    Minv = cv2.getPerspectiveTransform(dst, src)

def perspectify_test_images():
    images = glob.glob('test_images/*.jpg')
    for fname in images:

        img=mpimg.imread(fname)
        img_size = (img.shape[1], img.shape[0])
        warped = cv2.warpPerspective(img, M, img_size, flags=cv2.INTER_LINEAR)

        f, (ax1, ax2) = plt.subplots(1, 2, figsize=(24, 9))
        f.tight_layout()
        ax1.imshow(img)
        ax1.set_title('Original Image', fontsize=25)
        ax2.imshow(warped)
        ax2.set_title('Warped Image', fontsize=25)
        plt.subplots_adjust(left=0., right=1, top=0.9, bottom=0.)

        plt.savefig('output_images/perspective transform/' + fname.split('\\')[1])
        plt.show()

def get_perspective_matrix():
    find_Perspective_Matrix()
    return M,Minv

def get_top_view(img):
    #find_Perspective_Matrix()
    img_size = (img.shape[1], img.shape[0])
    warped = cv2.warpPerspective(img, M, img_size, flags=cv2.INTER_LINEAR)

    return warped

#find_Perspective_Matrix()
#perspectify_test_images()