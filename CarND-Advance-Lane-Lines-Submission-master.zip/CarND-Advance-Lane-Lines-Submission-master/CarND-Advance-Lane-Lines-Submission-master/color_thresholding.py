import numpy as np
import cv2
import glob
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

images = glob.glob('test_images/*.jpg')


def get_SThresholded(image):
    S_thresh = (130, 255)
    hls = cv2.cvtColor(image, cv2.COLOR_BGR2HLS)
    #H = hls[:, :, 0]
    #L = hls[:, :, 1]
    S = hls[:, :, 2]

    S_binary = np.zeros_like(S)
    S_binary[(S > S_thresh[0]) & (S <= S_thresh[1])] = 1

    return S_binary

def compare_HLS_RGB(image):

    S_thresh = (120,255)
    #R_thresh = (200,255)
    L_thresh = (120,255)

    # R = image[:, :, 0]
    # G = image[:, :, 1]
    # B = image[:, :, 2]

    hls = cv2.cvtColor(image, cv2.COLOR_RGB2HLS)
    H = hls[:, :, 0]
    L = hls[:, :, 1]
    S = hls[:, :, 2]

    # L_binary = np.zeros_like(L)
    # L_binary[((L > L_thresh[0]) & (L <= L_thresh[1])) ] = 1

    S_binary = np.zeros_like(S)
    S_binary[ ((S > S_thresh[0]) & (S <= S_thresh[1])) ] = 1 #& ((R > R_thresh[0]) & (R <= R_thresh[1]))

    #S_binary[ S_binary & L_binary]=1

    return S_binary

    # # plot
    # f, ( (ax1, ax2, ax3, ax4), (ax5, ax6, ax7, ax8)) = plt.subplots(2, 4, figsize=(24, 9))
    # f.tight_layout()
    #
    # ax1.imshow(image)
    # ax1.set_title('original', fontsize=25)
    #
    # ax2.imshow(H, cmap='gray')
    # ax2.set_title('H', fontsize=25)
    #
    # ax3.imshow(L, cmap='gray')
    # ax3.set_title('L', fontsize=25)
    #
    # ax4.imshow(S, cmap='gray')
    # ax4.set_title('S', fontsize=25)
    #
    # ax5.imshow(S_binary,cmap='gray')
    # ax5.set_title('S_binary', fontsize=25)
    #
    # ax6.imshow(R, cmap='gray')
    # ax6.set_title('R', fontsize=25)
    #s
    # ax7.imshow(G, cmap='gray')
    # ax7.set_title('G', fontsize=25)
    #
    # ax8.imshow(B, cmap='gray')
    # ax8.set_title('B', fontsize=25)
    #
    # # plt.subplots_adjust(left=0., right=1, top=0.9, bottom=0.)
    # plt.show()

def show_test_images():

    S_thresh = (130, 255)

    for fname in images:
        image = mpimg.imread(fname)

        compare_HLS_RGB(image)

        hls = cv2.cvtColor(image, cv2.COLOR_RGB2HLS)
        H = hls[:, :, 0]
        L = hls[:, :, 1]
        S = hls[:, :, 2]

        S_binary = np.zeros_like(S)
        S_binary[((S > S_thresh[0]) & (S <= S_thresh[1]))] = 1  # & ((R > R_thresh[0]) & (R <= R_thresh[1]))

        #plot
        f, ( ax1, ax2, ax3,ax4 ) = plt.subplots(1, 4, figsize=(24, 9))
        f.tight_layout()

        ax1.imshow(image)
        ax1.set_title('original', fontsize=25)

        ax2.imshow(S, cmap='gray')
        ax2.set_title('S', fontsize=25)

        ax3.imshow(L, cmap='gray')
        ax3.set_title('L', fontsize=25)

        ax4.imshow(S_binary, cmap='gray')
        ax4.set_title('S_binary', fontsize=25)

        plt.savefig('output_images/color analysis/' + fname.split('\\')[1])

#compare_HLS_RGB()