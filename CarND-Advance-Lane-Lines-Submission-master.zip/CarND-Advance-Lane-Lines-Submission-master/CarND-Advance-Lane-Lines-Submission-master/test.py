import numpy as np
import cv2
import matplotlib.image as mpimg
import matplotlib.pyplot as plt

f, ( (ax1, ax2), (ax3,ax4)) = plt.subplots(2, 2, figsize=(24, 9))
#images = glob.glob('camera_cal/calibration*.jpg')
img1= cv2.imread('test_images/test1.jpg')
img2=mpimg.imread('test_images/test1.jpg')

ax1.imshow(img1)
ax2.imshow(img1)
ax3.imshow(img1)
ax4.imshow(img1)
plt.show()

print(img1.shape,img2.shape)

gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
out_img = np.dstack((gray, gray, gray))*255

cv2.imshow("grayToRGB",out_img)
cv2.waitKey(5000)


import numpy as np
import cv2
import matplotlib.pyplot as plt

# # Assuming you have created a warped binary image called "binary_warped"
# # Take a histogram of the bottom half of the image
# histogram = np.sum(gray[gray.shape[0]/2:,:], axis=0)
# # Create an output image to draw on and  visualize the result
# # Find the peak of the left and right halves of the histogram
# # These will be the starting point for the left and right lines
# midpoint = np.int(histogram.shape[0]/2)
# leftx_base = np.argmax(histogram[:midpoint])
# rightx_base = np.argmax(histogram[midpoint:]) + midpoint